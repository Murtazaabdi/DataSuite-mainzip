import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import LandingPage from '@/pages/LandingPage';
import LoginPage from '@/pages/Login';
import DashboardLayout from '@/layouts/DashboardLayout';
import DashboardHome from '@/pages/dashboard/DashboardHome';
import IDEPage from '@/pages/dashboard/IDEPage';
import SQLWorkbenchPage from '@/pages/dashboard/SQLWorkbenchPage';
import DashboardStudioPage from '@/pages/dashboard/DashboardStudioPage';
import AIAnalystPage from '@/pages/dashboard/AIAnalystPage';
import WorkspacePage from '@/pages/dashboard/WorkspacePage';
import SettingsPage from '@/pages/dashboard/SettingsPage';
import AdminLayout from '@/layouts/AdminLayout';
import AdminDashboard from '@/pages/admin/AdminDashboard';
import AdminUsers from '@/pages/admin/AdminUsers';
import AdminAuditLogs from '@/pages/admin/AdminAuditLogs';
import AdminAIConfig from '@/pages/admin/AdminAIConfig';
import NotFound from '@/pages/NotFound';
import { Spinner } from '@/components/ui/spinner';
import { Toaster } from '@/components/ui/sonner';

function App() {
  const { user, isLoading, isAuthenticated } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: '#0B1120' }}>
        <Spinner className="h-8 w-8" />
      </div>
    );
  }

  return (
    <>
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={isAuthenticated ? <Navigate to="/dashboard" /> : <LoginPage />} />

        {/* Dashboard Routes */}
        <Route path="/dashboard" element={
          isAuthenticated ? <DashboardLayout /> : <Navigate to="/login" />
        }>
          <Route index element={<DashboardHome />} />
          <Route path="ide" element={<IDEPage />} />
          <Route path="sql" element={<SQLWorkbenchPage />} />
          <Route path="studio" element={<DashboardStudioPage />} />
          <Route path="ai" element={<AIAnalystPage />} />
          <Route path="workspace" element={<WorkspacePage />} />
          <Route path="settings" element={<SettingsPage />} />
        </Route>

        {/* Admin Routes */}
        <Route path="/admin" element={
          isAuthenticated && user?.role === 'admin' ? <AdminLayout /> : <Navigate to="/" />
        }>
          <Route index element={<AdminDashboard />} />
          <Route path="users" element={<AdminUsers />} />
          <Route path="audit" element={<AdminAuditLogs />} />
          <Route path="ai-config" element={<AdminAIConfig />} />
        </Route>

        {/* 404 */}
        <Route path="*" element={<NotFound />} />
      </Routes>
      <Toaster position="top-right" theme="dark" />
    </>
  );
}

export default App;
