import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { trpc } from '@/providers/trpc';
import {
  Code2,
  Database,
  LayoutDashboard,
  Sparkles,
  FileText,
  Zap,
  BarChart3,
  Clock,
} from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const quickActions = [
  { label: 'Open IDE', description: 'Write Python, R, SQL, JS', icon: <Code2 className="h-5 w-5" />, path: '/dashboard/ide', color: '#3B82F6' },
  { label: 'SQL Workbench', description: 'Query your data warehouse', icon: <Database className="h-5 w-5" />, path: '/dashboard/sql', color: '#10B981' },
  { label: 'Dashboard Studio', description: 'Build visual dashboards', icon: <LayoutDashboard className="h-5 w-5" />, path: '/dashboard/studio', color: '#06B6D4' },
  { label: 'AI Analyst', description: 'Chat with AI about data', icon: <Sparkles className="h-5 w-5" />, path: '/dashboard/ai', color: '#8B5CF6' },
  { label: 'Workspace', description: 'Documents & notebooks', icon: <FileText className="h-5 w-5" />, path: '/dashboard/workspace', color: '#F59E0B' },
];

const recentActivity = [
  { action: 'Executed SQL query', detail: 'SELECT * FROM sales_data', time: '2 min ago', type: 'sql' },
  { action: 'Created dashboard', detail: 'Q3 Revenue Overview', time: '15 min ago', type: 'dashboard' },
  { action: 'AI conversation', detail: 'Data analysis recommendations', time: '1 hour ago', type: 'ai' },
  { action: 'Saved workspace', detail: 'Project Alpha Spec', time: '3 hours ago', type: 'workspace' },
];

const tierInfo: Record<string, { name: string; color: string; limits: string }> = {
  free: { name: 'Free', color: '#64748B', limits: '50 AI requests/day' },
  analyst: { name: 'Analyst', color: '#3B82F6', limits: '500 AI requests/day' },
  data_scientist: { name: 'Data Scientist', color: '#8B5CF6', limits: '5,000 AI requests/day' },
  enterprise: { name: 'Enterprise', color: '#F59E0B', limits: 'Unlimited' },
};

export default function DashboardHome() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data: aiStats } = trpc.ai.getUsage.useQuery(undefined, { enabled: !!user });

  const tier = tierInfo[user?.tier || 'free'];
  const usagePercent = aiStats ? Math.min((aiStats.daily / aiStats.limit) * 100, 100) : 0;

  return (
    <div className="h-full overflow-auto p-6">
      {/* Welcome */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <h1 className="text-2xl font-semibold" style={{ color: '#F1F5F9' }}>
            Welcome back, {user?.name || 'User'}
          </h1>
          <Badge
            variant="outline"
            className="text-xs"
            style={{ borderColor: tier.color, color: tier.color, background: `${tier.color}15` }}
          >
            {tier.name} Tier
          </Badge>
        </div>
        <p className="text-sm" style={{ color: '#94A3B8' }}>
          Your data science workspace is ready. What would you like to work on today?
        </p>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        {[
          { label: 'AI Requests Today', value: aiStats?.daily ?? 0, icon: <Zap className="h-4 w-4" />, color: '#8B5CF6' },
          { label: 'Total AI Requests', value: aiStats?.total ?? 0, icon: <BarChart3 className="h-4 w-4" />, color: '#3B82F6' },
          { label: 'Dashboards', value: '3', icon: <LayoutDashboard className="h-4 w-4" />, color: '#06B6D4' },
          { label: 'Queries', value: '12', icon: <Database className="h-4 w-4" />, color: '#10B981' },
        ].map((stat, i) => (
          <Card
            key={i}
            className="p-4 border-0"
            style={{ background: '#151E32' }}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs" style={{ color: '#94A3B8' }}>{stat.label}</span>
              <div className="p-1.5 rounded-md" style={{ background: `${stat.color}15`, color: stat.color }}>
                {stat.icon}
              </div>
            </div>
            <div className="text-xl font-semibold" style={{ color: '#F1F5F9' }}>{stat.value}</div>
          </Card>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="mb-8">
        <h2 className="text-sm font-medium mb-4" style={{ color: '#F1F5F9' }}>Quick Actions</h2>
        <div className="grid grid-cols-5 gap-3">
          {quickActions.map((action, i) => (
            <Card
              key={i}
              className="p-4 border cursor-pointer transition-all hover:-translate-y-0.5"
              style={{
                background: '#151E32',
                borderColor: 'rgba(148, 163, 184, 0.1)',
              }}
              onClick={() => navigate(action.path)}
              onMouseEnter={e => {
                e.currentTarget.style.borderColor = `${action.color}40`;
                e.currentTarget.style.background = `${action.color}08`;
              }}
              onMouseLeave={e => {
                e.currentTarget.style.borderColor = 'rgba(148, 163, 184, 0.1)';
                e.currentTarget.style.background = '#151E32';
              }}
            >
              <div
                className="w-10 h-10 rounded-lg flex items-center justify-center mb-3"
                style={{ background: `${action.color}15`, color: action.color }}
              >
                {action.icon}
              </div>
              <div className="text-sm font-medium mb-1" style={{ color: '#F1F5F9' }}>{action.label}</div>
              <div className="text-xs" style={{ color: '#64748B' }}>{action.description}</div>
            </Card>
          ))}
        </div>
      </div>

      {/* Two Column Layout */}
      <div className="grid grid-cols-3 gap-6">
        {/* Usage */}
        <div>
          <h2 className="text-sm font-medium mb-4" style={{ color: '#F1F5F9' }}>AI Usage</h2>
          <Card className="p-4 border-0" style={{ background: '#151E32' }}>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs" style={{ color: '#94A3B8' }}>Daily Usage</span>
              <span className="text-xs" style={{ color: '#64748B' }}>{aiStats?.daily ?? 0} / {aiStats?.limit ?? 50}</span>
            </div>
            <div className="w-full h-2 rounded-full mb-4" style={{ background: '#1E293B' }}>
              <div
                className="h-full rounded-full transition-all"
                style={{
                  width: `${usagePercent}%`,
                  background: usagePercent > 80 ? '#F43F5E' : usagePercent > 50 ? '#F59E0B' : '#10B981',
                }}
              />
            </div>
            <div className="text-xs" style={{ color: '#64748B' }}>
              Resets at midnight UTC
            </div>
          </Card>
        </div>

        {/* Recent Activity */}
        <div className="col-span-2">
          <h2 className="text-sm font-medium mb-4" style={{ color: '#F1F5F9' }}>Recent Activity</h2>
          <Card className="border-0" style={{ background: '#151E32' }}>
            {recentActivity.map((item, i) => (
              <div
                key={i}
                className="flex items-center gap-3 px-4 py-3 transition-colors cursor-pointer"
                style={{ borderBottom: i < recentActivity.length - 1 ? '1px solid rgba(148, 163, 184, 0.05)' : 'none' }}
                onMouseEnter={e => { e.currentTarget.style.background = '#1E293B'; }}
                onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; }}
              >
                <div
                  className="w-8 h-8 rounded-md flex items-center justify-center"
                  style={{
                    background: item.type === 'sql' ? '#10B98115' :
                      item.type === 'dashboard' ? '#06B6D415' :
                        item.type === 'ai' ? '#8B5CF615' : '#F59E0B15',
                    color: item.type === 'sql' ? '#10B981' :
                      item.type === 'dashboard' ? '#06B6D4' :
                        item.type === 'ai' ? '#8B5CF6' : '#F59E0B',
                  }}
                >
                  {item.type === 'sql' && <Database className="h-4 w-4" />}
                  {item.type === 'dashboard' && <LayoutDashboard className="h-4 w-4" />}
                  {item.type === 'ai' && <Sparkles className="h-4 w-4" />}
                  {item.type === 'workspace' && <FileText className="h-4 w-4" />}
                </div>
                <div className="flex-1">
                  <div className="text-sm" style={{ color: '#F1F5F9' }}>{item.action}</div>
                  <div className="text-xs" style={{ color: '#64748B' }}>{item.detail}</div>
                </div>
                <div className="flex items-center gap-1 text-xs" style={{ color: '#64748B' }}>
                  <Clock className="h-3 w-3" />
                  {item.time}
                </div>
              </div>
            ))}
          </Card>
        </div>
      </div>
    </div>
  );
}
