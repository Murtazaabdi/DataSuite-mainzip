import { useState, useRef, useEffect } from 'react';
import { trpc } from '@/providers/trpc';
import {
  Send,
  Bot,
  User,
  Plus,
  Trash2,
  Sparkles,
  Loader2,
  MessageSquare,
  BarChart3,
  Code2,
  Database,
  ChevronRight,
  Zap,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

const suggestedPrompts = [
  { icon: <Code2 className="h-4 w-4" />, label: 'Write SQL', description: 'Generate a query to analyze sales' },
  { icon: <BarChart3 className="h-4 w-4" />, label: 'Build Dashboard', description: 'Design a revenue dashboard' },
  { icon: <Database className="h-4 w-4" />, label: 'Data Analysis', description: 'Analyze customer churn patterns' },
  { icon: <Zap className="h-4 w-4" />, label: 'Optimize Query', description: 'Optimize slow running queries' },
];

export default function AIAnalystPage() {
  const [activeConversationId, setActiveConversationId] = useState<number | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const utils = trpc.useUtils();
  const { data: conversations } = trpc.ai.listConversations.useQuery();
  const { data: usage } = trpc.ai.getUsage.useQuery();
  const sendMessageMutation = trpc.ai.sendMessage.useMutation();
  const createConversationMutation = trpc.ai.createConversation.useMutation();
  const deleteConversationMutation = trpc.ai.deleteConversation.useMutation();
  const { data: conversationData } = trpc.ai.getConversation.useQuery(
    { id: activeConversationId! },
    { enabled: !!activeConversationId }
  );

  useEffect(() => {
    if (conversationData?.messages) {
      setMessages(
        conversationData.messages.map(m => ({
          id: String(m.id),
          role: m.role as 'user' | 'assistant',
          content: m.content,
          timestamp: new Date(m.createdAt),
        }))
      );
    }
  }, [conversationData]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleNewConversation = async () => {
    const result = await createConversationMutation.mutateAsync({ title: 'New Conversation' });
    setActiveConversationId(result.id);
    setMessages([]);
    utils.ai.listConversations.invalidate();
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;

    const content = inputValue.trim();
    setInputValue('');
    setIsLoading(true);

    // If no active conversation, create one
    let convId = activeConversationId;
    if (!convId) {
      const result = await createConversationMutation.mutateAsync({
        title: content.slice(0, 50) + (content.length > 50 ? '...' : ''),
      });
      convId = result.id;
      setActiveConversationId(result.id);
    }

    // Add user message immediately
    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMessage]);

    try {
      const result = await sendMessageMutation.mutateAsync({
        conversationId: convId!,
        content,
      });

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: result.response,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, assistantMessage]);
      utils.ai.getUsage.invalidate();
    } catch (err: any) {
      const errorMsg = err?.message || 'Failed to get response';
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: `**Error:** ${errorMsg}\n\nPlease try again or contact support if the issue persists.`,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, assistantMessage]);
    } finally {
      setIsLoading(false);
      utils.ai.listConversations.invalidate();
    }
  };

  const handleDeleteConversation = async (id: number) => {
    await deleteConversationMutation.mutateAsync({ id });
    if (activeConversationId === id) {
      setActiveConversationId(null);
      setMessages([]);
    }
    utils.ai.listConversations.invalidate();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const usagePercent = usage ? Math.min((usage.daily / usage.limit) * 100, 100) : 0;

  return (
    <div className="h-full flex">
      {/* Sidebar */}
      {sidebarOpen && (
        <div
          className="w-64 border-r flex flex-col"
          style={{ background: '#151E32', borderColor: 'rgba(148, 163, 184, 0.1)' }}
        >
          <div className="p-3">
            <Button
              onClick={handleNewConversation}
              className="w-full gap-2 text-white"
              style={{ background: '#3B82F6' }}
            >
              <Plus className="h-4 w-4" />
              New Chat
            </Button>
          </div>

          <div
            className="mx-3 mb-2"
            style={{ height: 1, background: 'rgba(148, 163, 184, 0.1)' }}
          />

          <ScrollArea className="flex-1">
            <div className="px-3 py-2">
              <div className="text-xs font-medium mb-2" style={{ color: '#64748B' }}>CONVERSATIONS</div>
              {conversations?.map(conv => (
                <div
                  key={conv.id}
                  onClick={() => setActiveConversationId(conv.id)}
                  className="flex items-center gap-2 px-2 py-2 rounded cursor-pointer group"
                  style={{
                    background: activeConversationId === conv.id ? '#243447' : 'transparent',
                  }}
                  onMouseEnter={e => {
                    if (activeConversationId !== conv.id) e.currentTarget.style.background = '#1E293B';
                  }}
                  onMouseLeave={e => {
                    if (activeConversationId !== conv.id) e.currentTarget.style.background = 'transparent';
                  }}
                >
                  <MessageSquare className="h-4 w-4 flex-shrink-0" style={{ color: '#94A3B8' }} />
                  <span className="text-xs flex-1 truncate" style={{ color: activeConversationId === conv.id ? '#F1F5F9' : '#94A3B8' }}>
                    {conv.title}
                  </span>
                  <button
                    onClick={(e) => { e.stopPropagation(); handleDeleteConversation(conv.id); }}
                    className="opacity-0 group-hover:opacity-100 p-1 rounded"
                  >
                    <Trash2 className="h-3 w-3" style={{ color: '#64748B' }} />
                  </button>
                </div>
              ))}
            </div>
          </ScrollArea>

          {/* Usage */}
          <div className="p-3 border-t" style={{ borderColor: 'rgba(148, 163, 184, 0.1)' }}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs" style={{ color: '#94A3B8' }}>Daily Usage</span>
              <span className="text-xs" style={{ color: '#64748B' }}>{usage?.daily ?? 0}/{usage?.limit ?? 50}</span>
            </div>
            <div className="w-full h-1.5 rounded-full" style={{ background: '#1E293B' }}>
              <div
                className="h-full rounded-full"
                style={{
                  width: `${usagePercent}%`,
                  background: usagePercent > 80 ? '#F43F5E' : '#3B82F6',
                }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col" style={{ background: '#0B1120' }}>
        {/* Header */}
        <div
          className="flex items-center justify-between px-4 py-2 border-b"
          style={{ background: '#151E32', borderColor: 'rgba(148, 163, 184, 0.1)' }}
        >
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              onClick={() => setSidebarOpen(!sidebarOpen)}
              style={{ color: '#94A3B8' }}
            >
              <ChevronRight className={`h-4 w-4 transition-transform ${sidebarOpen ? 'rotate-180' : ''}`} />
            </Button>
            <div className="flex items-center gap-2">
              <div
                className="w-6 h-6 rounded-md flex items-center justify-center"
                style={{ background: 'linear-gradient(135deg, #8B5CF6, #3B82F6)' }}
              >
                <Sparkles className="h-3.5 w-3.5 text-white" />
              </div>
              <span className="text-sm font-medium" style={{ color: '#F1F5F9' }}>AI Analyst</span>
            </div>
          </div>
          <Badge
            variant="outline"
            className="text-xs"
            style={{ borderColor: '#8B5CF6', color: '#8B5CF6', background: 'rgba(139, 92, 246, 0.1)' }}
          >
            {usage?.tier || 'free'} tier
          </Badge>
        </div>

        {/* Messages */}
        <ScrollArea className="flex-1">
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full px-8 py-12">
              <div
                className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6"
                style={{ background: 'linear-gradient(135deg, #8B5CF6, #3B82F6)' }}
              >
                <Bot className="h-8 w-8 text-white" />
              </div>
              <h2 className="text-xl font-semibold mb-2" style={{ color: '#F1F5F9' }}>
                How can I help you today?
              </h2>
              <p className="text-sm text-center mb-8 max-w-md" style={{ color: '#94A3B8' }}>
                I can help you write SQL queries, analyze data, build dashboards, write Python/R code, and much more.
              </p>

              <div className="grid grid-cols-2 gap-3 w-full max-w-lg">
                {suggestedPrompts.map((prompt, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      setInputValue(`Help me ${prompt.label.toLowerCase()}: ${prompt.description}`);
                    }}
                    className="flex items-start gap-3 p-3 rounded-lg text-left transition-colors"
                    style={{
                      background: '#151E32',
                      border: '1px solid rgba(148, 163, 184, 0.1)',
                    }}
                    onMouseEnter={e => {
                      e.currentTarget.style.borderColor = 'rgba(139, 92, 246, 0.3)';
                      e.currentTarget.style.background = 'rgba(139, 92, 246, 0.05)';
                    }}
                    onMouseLeave={e => {
                      e.currentTarget.style.borderColor = 'rgba(148, 163, 184, 0.1)';
                      e.currentTarget.style.background = '#151E32';
                    }}
                  >
                    <div className="p-1.5 rounded-md" style={{ background: 'rgba(139, 92, 246, 0.1)', color: '#8B5CF6' }}>
                      {prompt.icon}
                    </div>
                    <div>
                      <div className="text-sm font-medium" style={{ color: '#F1F5F9' }}>{prompt.label}</div>
                      <div className="text-xs" style={{ color: '#64748B' }}>{prompt.description}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="py-4 px-4 space-y-4">
              {messages.map(message => (
                <div
                  key={message.id}
                  className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {message.role === 'assistant' && (
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-1"
                      style={{ background: 'linear-gradient(135deg, #8B5CF6, #3B82F6)' }}
                    >
                      <Bot className="h-4 w-4 text-white" />
                    </div>
                  )}
                  <div
                    className="max-w-2xl px-4 py-3 rounded-xl"
                    style={{
                      background: message.role === 'user' ? '#3B82F6' : '#151E32',
                      border: message.role === 'assistant' ? '1px solid rgba(148, 163, 184, 0.1)' : 'none',
                    }}
                  >
                    <div
                      className="text-sm whitespace-pre-wrap prose prose-invert prose-sm max-w-none"
                      style={{ color: message.role === 'user' ? '#fff' : '#F1F5F9' }}
                      dangerouslySetInnerHTML={{
                        __html: formatMessage(message.content),
                      }}
                    />
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-xs" style={{ color: message.role === 'user' ? 'rgba(255,255,255,0.5)' : '#64748B' }}>
                        {formatTime(message.timestamp)}
                      </span>
                    </div>
                  </div>
                  {message.role === 'user' && (
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-1"
                      style={{ background: '#1E293B' }}
                    >
                      <User className="h-4 w-4" style={{ color: '#94A3B8' }} />
                    </div>
                  )}
                </div>
              ))}
              {isLoading && (
                <div className="flex gap-3">
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ background: 'linear-gradient(135deg, #8B5CF6, #3B82F6)' }}
                  >
                    <Bot className="h-4 w-4 text-white" />
                  </div>
                  <div
                    className="px-4 py-3 rounded-xl"
                    style={{ background: '#151E32', border: '1px solid rgba(148, 163, 184, 0.1)' }}
                  >
                    <div className="flex items-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin" style={{ color: '#8B5CF6' }} />
                      <span className="text-sm" style={{ color: '#94A3B8' }}>Analyzing...</span>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </ScrollArea>

        {/* Input */}
        <div className="p-4 border-t" style={{ borderColor: 'rgba(148, 163, 184, 0.1)' }}>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="h-9 w-9" style={{ color: '#64748B' }}>
              <Sparkles className="h-4 w-4" />
            </Button>
            <div className="flex-1 flex items-center rounded-xl px-4" style={{ background: '#151E32', border: '1px solid rgba(148, 163, 184, 0.1)' }}>
              <input
                value={inputValue}
                onChange={e => setInputValue(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask me anything about your data..."
                className="flex-1 bg-transparent py-3 text-sm outline-none"
                style={{ color: '#F1F5F9' }}
              />
            </div>
            <Button
              onClick={handleSendMessage}
              disabled={!inputValue.trim() || isLoading}
              className="h-9 w-9 p-0"
              style={{ background: '#3B82F6' }}
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
          <div className="text-center mt-2">
            <span className="text-xs" style={{ color: '#475569' }}>
              AI responses are generated to assist your analysis. Always verify critical results.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

// Format message with code blocks
function formatMessage(content: string): string {
  let formatted = content
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/### (.*)/g, '<h3 class="text-lg font-semibold mt-4 mb-2">$1</h3>')
    .replace(/## (.*)/g, '<h2 class="text-xl font-semibold mt-4 mb-2">$1</h2>')
    .replace(/# (.*)/g, '<h1 class="text-2xl font-bold mt-4 mb-2">$1</h1>');

  // Code blocks
  formatted = formatted.replace(
    /```(\w+)?\n([\s\S]*?)```/g,
    '<pre class="bg-[#0B1120] border border-[rgba(148,163,184,0.1)] rounded-lg p-3 my-2 overflow-x-auto"><code class="text-xs font-mono" style="color:#F1F5F9">$2</code></pre>'
  );

  // Inline code
  formatted = formatted.replace(
    /`([^`]+)`/g,
    '<code class="px-1.5 py-0.5 rounded text-xs font-mono" style="background:#1E293B;color:#06B6D4">$1</code>'
  );

  return formatted;
}
