import { useState, useRef, useCallback } from 'react';
import Editor from '@monaco-editor/react';
import {
  Play,
  Save,
  Share2,
  ChevronDown,
  X,
  FileCode,
  FileText,
  Plus,
  Terminal,
  CircleDot,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { ScrollArea } from '@/components/ui/scroll-area';

interface FileItem {
  id: string;
  name: string;
  content: string;
  language: string;
  saved: boolean;
}

const pythonContent = [
  '# Data Analysis Script',
  'import pandas as pd',
  'import numpy as np',
  'import matplotlib.pyplot as plt',
  '',
  '# Load sample data',
  "data = {\n    'month': ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],\n    'revenue': [120000, 135000, 148000, 162000, 155000, 178000],\n    'expenses': [95000, 102000, 110000, 118000, 115000, 125000],\n    'customers': [1200, 1350, 1480, 1620, 1580, 1750]\n}",
  '',
  'df = pd.DataFrame(data)',
  "df['profit'] = df['revenue'] - df['expenses']",
  "df['margin'] = (df['profit'] / df['revenue'] * 100).round(2)",
  '',
  '# Summary statistics',
  'print("=== Revenue Analysis ===")',
  'print(f"Total Revenue: USD {df[\'revenue\'].sum():,}")',
  'print(f"Total Profit: USD {df[\'profit\'].sum():,}")',
  'print(f"Avg Margin: {df[\'margin\'].mean():.1f}%")',
  'print(f"Top Month: {df.loc[df[\'profit\'].idxmax(), \'month\']}")',
].join('\n');

const sqlContent = [
  '-- Revenue Analysis Query',
  'SELECT',
  '    region,',
  '    product_line,',
  '    SUM(revenue) as total_revenue,',
  '    SUM(profit) as total_profit,',
  '    ROUND(AVG(margin_pct), 2) as avg_margin,',
  '    COUNT(*) as transaction_count',
  'FROM sales_data',
  "WHERE date >= '2024-01-01'",
  "  AND status = 'completed'",
  'GROUP BY region, product_line',
  'HAVING SUM(revenue) > 50000',
  'ORDER BY total_revenue DESC',
  'LIMIT 100;',
].join('\n');

const rContent = [
  '# Linear Regression Model',
  'library(ggplot2)',
  '',
  '# Load data',
  'data <- read.csv("sales_data.csv")',
  '',
  '# Build model',
  'model <- lm(revenue ~ marketing_spend + customer_count + season, data = data)',
  '',
  '# Summary',
  'print(summary(model))',
  '',
  '# Predictions',
  'new_data <- data.frame(',
  '  marketing_spend = c(50000, 75000, 100000),',
  '  customer_count = c(1000, 1500, 2000),',
  '  season = c("Q1", "Q2", "Q3")',
  ')',
  '',
  'predictions <- predict(model, newdata = new_data)',
  'print(predictions)',
].join('\n');

const defaultFiles: FileItem[] = [
  { id: '1', name: 'analysis.py', content: pythonContent, language: 'python', saved: true },
  { id: '2', name: 'query.sql', content: sqlContent, language: 'sql', saved: true },
  { id: '3', name: 'model.r', content: rContent, language: 'r', saved: true },
];

const languageOptions = [
  { value: 'python', label: 'Python', icon: <CircleDot className="h-4 w-4" style={{ color: '#3B82F6' }} /> },
  { value: 'sql', label: 'SQL', icon: <CircleDot className="h-4 w-4" style={{ color: '#10B981' }} /> },
  { value: 'r', label: 'R', icon: <CircleDot className="h-4 w-4" style={{ color: '#F59E0B' }} /> },
  { value: 'javascript', label: 'JavaScript', icon: <CircleDot className="h-4 w-4" style={{ color: '#FBBF24' }} /> },
];

const fileIcons: Record<string, React.ReactNode> = {
  python: <FileCode className="h-4 w-4" style={{ color: '#3B82F6' }} />,
  sql: <FileCode className="h-4 w-4" style={{ color: '#10B981' }} />,
  r: <FileCode className="h-4 w-4" style={{ color: '#F59E0B' }} />,
  javascript: <FileCode className="h-4 w-4" style={{ color: '#FBBF24' }} />,
  default: <FileText className="h-4 w-4" style={{ color: '#94A3B8' }} />,
};

const mockPythonOutput = [
  '=== Revenue Analysis ===',
  'Total Revenue: USD 898,000',
  'Total Profit: USD 183,000',
  'Avg Margin: 20.4%',
  '',
  'Top Month: Jun',
  'Profit: USD 53,000',
  '',
  'Process completed in 1.24s',
].join('\n');

const mockSQLOutput = [
  'region    | product_line  | total_revenue | total_profit | avg_margin | tx_count',
  '----------|---------------|---------------|--------------|------------|----------',
  'North     | Electronics   | USD 245,000   | USD 73,500   | 30.00      | 45',
  'West      | Software      | USD 198,000   | USD 59,400   | 30.00      | 38',
  'South     | Services      | USD 156,000   | USD 31,200   | 20.00      | 29',
  'East      | Electronics   | USD 134,000   | USD 26,800   | 20.00      | 25',
  '',
  '4 rows returned in 450ms',
].join('\n');

const mockROutput = [
  'Call: lm(formula = revenue ~ marketing_spend + customer_count + season)',
  '',
  'Residuals: Min -2450, 1Q -678, Median 123, 3Q 890, Max 3120',
  '',
  'Coefficients:',
  '  (Intercept)     5234.1   sig: 0.000123',
  '  marketing_spend    2.45   sig: 0.0000000000000002',
  '  customer_count    45.23   sig: 0.0000000000000002',
  '  seasonQ2        1234.5   sig: 0.034',
  '  seasonQ3        3456.7   sig: 0.00000245',
  '',
  'R-squared: 0.9234, Adj R-squared: 0.9201',
  'F-statistic: 282.3, p-value: 0.00000000000000022',
].join('\n');

const mockJSOutput = [
  'Output:',
  '{',
  '  status: "success",',
  '  processed: 1000,',
  '  duration: "2.45s",',
  '  results: [Array(1000)]',
  '}',
].join('\n');

export default function IDEPage() {
  const [files, setFiles] = useState<FileItem[]>(defaultFiles);
  const [activeFileId, setActiveFileId] = useState('1');
  const [output, setOutput] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [terminalHeight] = useState(200);
  const editorRef = useRef(null);

  const activeFile = files.find(f => f.id === activeFileId) || files[0];

  const handleEditorChange = useCallback((value: string | undefined) => {
    if (value === undefined) return;
    setFiles(prev =>
      prev.map(f =>
        f.id === activeFileId ? { ...f, content: value, saved: false } : f
      )
    );
  }, [activeFileId]);

  const handleSave = () => {
    setFiles(prev =>
      prev.map(f =>
        f.id === activeFileId ? { ...f, saved: true } : f
      )
    );
  };

  const handleRun = () => {
    setIsRunning(true);
    setOutput('');
    setTimeout(() => {
      const lang = activeFile.language;
      if (lang === 'python') setOutput(mockPythonOutput);
      else if (lang === 'sql') setOutput(mockSQLOutput);
      else if (lang === 'r') setOutput(mockROutput);
      else if (lang === 'javascript') setOutput(mockJSOutput);
      else setOutput('Code executed successfully.\nProcess completed.');
      setIsRunning(false);
    }, 1500);
  };

  const addNewFile = () => {
    const newFile: FileItem = {
      id: Date.now().toString(),
      name: `untitled_${files.length + 1}.py`,
      content: '# New file\n',
      language: 'python',
      saved: false,
    };
    setFiles(prev => [...prev, newFile]);
    setActiveFileId(newFile.id);
  };

  const deleteFile = (id: string) => {
    setFiles(prev => {
      const newFiles = prev.filter(f => f.id !== id);
      if (activeFileId === id && newFiles.length > 0) {
        setActiveFileId(newFiles[0].id);
      }
      return newFiles;
    });
  };

  return (
    <div className="h-full flex flex-col">
      {/* Toolbar */}
      <div
        className="flex items-center justify-between px-4 py-2 border-b"
        style={{ background: '#151E32', borderColor: 'rgba(148, 163, 184, 0.1)' }}
      >
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            onClick={handleRun}
            disabled={isRunning}
            className="gap-1.5 text-white"
            style={{ background: '#10B981' }}
          >
            <Play className="h-3.5 w-3.5" />
            {isRunning ? 'Running...' : 'Run'}
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="gap-1"
                style={{ color: '#94A3B8' }}
              >
                {languageOptions.find(l => l.value === activeFile.language)?.icon}
                <span className="text-xs">{languageOptions.find(l => l.value === activeFile.language)?.label}</span>
                <ChevronDown className="h-3 w-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent style={{ background: '#151E32', borderColor: 'rgba(148, 163, 184, 0.2)' }}>
              {languageOptions.map(lang => (
                <DropdownMenuItem
                  key={lang.value}
                  onClick={() => {
                    setFiles(prev =>
                      prev.map(f =>
                        f.id === activeFileId ? { ...f, language: lang.value } : f
                      )
                    );
                  }}
                  className="gap-2"
                  style={{ color: '#94A3B8' }}
                >
                  {lang.icon}
                  {lang.label}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          <div className="w-px h-5 mx-1" style={{ background: 'rgba(148, 163, 184, 0.1)' }} />

          <Button variant="ghost" size="sm" onClick={handleSave} className="gap-1" style={{ color: '#94A3B8' }}>
            <Save className="h-3.5 w-3.5" />
            <span className="text-xs">Save</span>
          </Button>

          <Button variant="ghost" size="sm" className="gap-1" style={{ color: '#94A3B8' }}>
            <Share2 className="h-3.5 w-3.5" />
            <span className="text-xs">Share</span>
          </Button>
        </div>

        <div className="flex items-center gap-1">
          {!activeFile.saved && (
            <div className="w-2 h-2 rounded-full mr-2" style={{ background: '#F59E0B' }} />
          )}
        </div>
      </div>

      {/* Editor Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* File Explorer */}
        <div
          className="w-48 border-r flex flex-col"
          style={{ background: '#151E32', borderColor: 'rgba(148, 163, 184, 0.1)' }}
        >
          <div
            className="flex items-center justify-between px-3 py-2 border-b"
            style={{ borderColor: 'rgba(148, 163, 184, 0.1)' }}
          >
            <span className="text-xs font-medium" style={{ color: '#94A3B8' }}>EXPLORER</span>
            <Button variant="ghost" size="icon" className="h-6 w-6" onClick={addNewFile}>
              <Plus className="h-3.5 w-3.5" style={{ color: '#94A3B8' }} />
            </Button>
          </div>
          <ScrollArea className="flex-1">
            {files.map(file => (
              <div
                key={file.id}
                onClick={() => setActiveFileId(file.id)}
                className="flex items-center gap-2 px-3 py-1.5 cursor-pointer group"
                style={{
                  background: activeFileId === file.id ? '#243447' : 'transparent',
                  borderLeft: activeFileId === file.id ? '2px solid #3B82F6' : '2px solid transparent',
                }}
              >
                {fileIcons[file.language] || fileIcons.default}
                <span
                  className="text-xs flex-1 truncate"
                  style={{ color: activeFileId === file.id ? '#F1F5F9' : '#94A3B8' }}
                >
                  {file.name}
                  {!file.saved && ' *'}
                </span>
                <button
                  onClick={(e) => { e.stopPropagation(); deleteFile(file.id); }}
                  className="opacity-0 group-hover:opacity-100 p-0.5 rounded"
                >
                  <X className="h-3 w-3" style={{ color: '#64748B' }} />
                </button>
              </div>
            ))}
          </ScrollArea>
        </div>

        {/* Editor */}
        <div className="flex-1 flex flex-col">
          <Editor
            height="100%"
            language={activeFile.language === 'r' ? 'r' : activeFile.language}
            value={activeFile.content}
            onChange={handleEditorChange}
            theme="vs-dark"
            options={{
              fontSize: 14,
              fontFamily: 'JetBrains Mono, monospace',
              minimap: { enabled: true },
              lineNumbers: 'on',
              folding: true,
              bracketPairColorization: { enabled: true },
              autoIndent: 'full',
              tabSize: 4,
              wordWrap: 'on',
              scrollBeyondLastLine: false,
              padding: { top: 16 },
            }}
            onMount={(editor) => { editorRef.current = editor as any; }}
          />

          {/* Terminal */}
          {output && (
            <div
              className="border-t"
              style={{
                height: terminalHeight,
                background: '#0B1120',
                borderColor: 'rgba(148, 163, 184, 0.1)',
              }}
            >
              <div
                className="flex items-center justify-between px-4 py-1.5 border-b"
                style={{ borderColor: 'rgba(148, 163, 184, 0.1)' }}
              >
                <div className="flex items-center gap-2">
                  <Terminal className="h-3.5 w-3.5" style={{ color: '#94A3B8' }} />
                  <span className="text-xs" style={{ color: '#94A3B8' }}>TERMINAL</span>
                </div>
                <div className="flex items-center gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-5 px-2 text-xs"
                    onClick={() => setOutput('')}
                    style={{ color: '#64748B' }}
                  >
                    Clear
                  </Button>
                  <Button variant="ghost" size="icon" className="h-5 w-5" onClick={() => setOutput('')}>
                    <X className="h-3 w-3" style={{ color: '#64748B' }} />
                  </Button>
                </div>
              </div>
              <ScrollArea className="p-4" style={{ height: terminalHeight - 40 }}>
                <pre
                  className="text-xs font-mono whitespace-pre-wrap"
                  style={{ color: '#F1F5F9', fontFamily: 'JetBrains Mono, monospace' }}
                >
                  {output}
                </pre>
              </ScrollArea>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
