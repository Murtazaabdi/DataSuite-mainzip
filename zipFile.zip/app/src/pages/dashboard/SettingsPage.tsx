import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { trpc } from '@/providers/trpc';
import {
  User,
  CreditCard,
  Shield,
  Bell,
  Monitor,
  CheckCircle2,
  Loader2,
  Smartphone,
  Copy,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';

const tabs = [
  { id: 'profile', label: 'Profile', icon: <User className="h-4 w-4" /> },
  { id: 'billing', label: 'Billing', icon: <CreditCard className="h-4 w-4" /> },
  { id: 'security', label: 'Security', icon: <Shield className="h-4 w-4" /> },
  { id: 'notifications', label: 'Notifications', icon: <Bell className="h-4 w-4" /> },
];

const tierInfo: Record<string, { name: string; color: string; price: string; features: string[] }> = {
  free: {
    name: 'Free',
    color: '#64748B',
    price: '$0',
    features: ['Basic IDE', 'SQLite only', '1 Dashboard', '50 AI requests/day'],
  },
  analyst: {
    name: 'Analyst',
    color: '#3B82F6',
    price: '$29/mo',
    features: ['Full IDE', 'PostgreSQL schema', '10 Dashboards', '500 AI requests/day', 'CSV upload'],
  },
  data_scientist: {
    name: 'Data Scientist',
    color: '#8B5CF6',
    price: '$79/mo',
    features: ['Unlimited IDE', '200GB storage', 'Unlimited dashboards', '5,000 AI requests/day', 'Team sharing'],
  },
  enterprise: {
    name: 'Enterprise',
    color: '#F59E0B',
    price: '$299/mo',
    features: ['Dedicated support', 'SLA', 'White-label', 'Unlimited everything'],
  },
};

export default function SettingsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('profile');
  const [twoFactorStep, setTwoFactorStep] = useState<'idle' | 'setup' | 'verify'>('idle');
  const [totpCode, setTotpCode] = useState('');
  const [totpSecret, setTotpSecret] = useState('');
  const [notifications, setNotifications] = useState({
    email: true,
    browser: false,
    marketing: false,
    security: true,
  });

  const { data: twoFAStatus } = trpc.user.get2FAStatus.useQuery();
  const { refetch: setup2FARefetch } = trpc.user.setup2FA.useQuery(undefined, { enabled: false });
  const verify2FAMutation = trpc.user.verify2FA.useMutation();
  const disable2FAMutation = trpc.user.disable2FA.useMutation();
  const utils = trpc.useUtils();

  const tier = tierInfo[user?.tier || 'free'];

  const handleSetup2FA = async () => {
    const { data } = await setup2FARefetch();
    if (data) {
      setTotpSecret(data.secret);
      setTwoFactorStep('setup');
    }
  };

  const handleVerify2FA = async () => {
    if (totpCode.length !== 6) return;
    const result = await verify2FAMutation.mutateAsync({ code: totpCode });
    if (result.success) {
      setTwoFactorStep('idle');
      setTotpCode('');
      utils.user.get2FAStatus.invalidate();
      toast({ title: '2FA Enabled', description: 'Two-factor authentication is now active.' });
    } else {
      toast({ title: 'Verification Failed', description: result.message, variant: 'destructive' });
    }
  };

  const handleDisable2FA = async () => {
    if (totpCode.length !== 6) return;
    const result = await disable2FAMutation.mutateAsync({ code: totpCode });
    if (result.success) {
      setTotpCode('');
      utils.user.get2FAStatus.invalidate();
      toast({ title: '2FA Disabled', description: 'Two-factor authentication has been turned off.' });
    } else {
      toast({ title: 'Error', description: result.message, variant: 'destructive' });
    }
  };

  return (
    <div className="h-full flex">
      {/* Settings Sidebar */}
      <div
        className="w-56 border-r"
        style={{ background: '#151E32', borderColor: 'rgba(148, 163, 184, 0.1)' }}
      >
        <ScrollArea className="h-full">
          <div className="p-3">
            <div className="text-xs font-medium mb-3 px-2" style={{ color: '#64748B' }}>SETTINGS</div>
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className="w-full flex items-center gap-2 px-2 py-2 rounded text-left transition-colors"
                style={{
                  background: activeTab === tab.id ? '#243447' : 'transparent',
                  color: activeTab === tab.id ? '#F1F5F9' : '#94A3B8',
                  borderLeft: activeTab === tab.id ? '2px solid #3B82F6' : '2px solid transparent',
                }}
              >
                {tab.icon}
                <span className="text-xs">{tab.label}</span>
              </button>
            ))}
          </div>
        </ScrollArea>
      </div>

      {/* Content */}
      <ScrollArea className="flex-1">
        <div className="max-w-2xl mx-auto py-8 px-6">
          {/* Profile Tab */}
          {activeTab === 'profile' && (
            <div>
              <h2 className="text-lg font-semibold mb-1" style={{ color: '#F1F5F9' }}>Profile</h2>
              <p className="text-sm mb-6" style={{ color: '#94A3B8' }}>Manage your personal information</p>

              <Card className="p-6 mb-4 border-0" style={{ background: '#151E32' }}>
                <div className="flex items-center gap-4 mb-6">
                  <div
                    className="w-16 h-16 rounded-full flex items-center justify-center text-xl font-semibold"
                    style={{ background: 'linear-gradient(135deg, #3B82F6, #8B5CF6)', color: '#fff' }}
                  >
                    {user?.name?.charAt(0)?.toUpperCase() || 'U'}
                  </div>
                  <div>
                    <div className="text-sm font-medium" style={{ color: '#F1F5F9' }}>{user?.name || 'User'}</div>
                    <div className="text-xs" style={{ color: '#94A3B8' }}>{user?.email || ''}</div>
                    <Badge
                      variant="outline"
                      className="mt-1 text-xs"
                      style={{ borderColor: tier.color, color: tier.color, background: `${tier.color}15` }}
                    >
                      {tier.name}
                    </Badge>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-xs block mb-1.5" style={{ color: '#94A3B8' }}>Full Name</label>
                    <Input
                      defaultValue={user?.name || ''}
                      className="h-9 text-sm"
                      style={{ background: '#1E293B', borderColor: 'rgba(148, 163, 184, 0.2)', color: '#F1F5F9' }}
                    />
                  </div>
                  <div>
                    <label className="text-xs block mb-1.5" style={{ color: '#94A3B8' }}>Email</label>
                    <Input
                      defaultValue={user?.email || ''}
                      readOnly
                      className="h-9 text-sm"
                      style={{ background: '#1E293B', borderColor: 'rgba(148, 163, 184, 0.2)', color: '#64748B' }}
                    />
                  </div>
                  <div>
                    <label className="text-xs block mb-1.5" style={{ color: '#94A3B8' }}>Organization</label>
                    <Input
                      placeholder="Your organization"
                      className="h-9 text-sm"
                      style={{ background: '#1E293B', borderColor: 'rgba(148, 163, 184, 0.2)', color: '#F1F5F9' }}
                    />
                  </div>
                  <Button className="text-xs" style={{ background: '#3B82F6' }}>
                    Save Changes
                  </Button>
                </div>
              </Card>
            </div>
          )}

          {/* Billing Tab */}
          {activeTab === 'billing' && (
            <div>
              <h2 className="text-lg font-semibold mb-1" style={{ color: '#F1F5F9' }}>Billing</h2>
              <p className="text-sm mb-6" style={{ color: '#94A3B8' }}>Manage your subscription and usage</p>

              <Card className="p-6 mb-4 border-0" style={{ background: '#151E32' }}>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <div className="text-sm font-medium" style={{ color: '#F1F5F9' }}>Current Plan</div>
                    <div className="text-xs" style={{ color: '#94A3B8' }}>Your subscription details</div>
                  </div>
                  <Badge
                    variant="outline"
                    className="text-sm px-3 py-1"
                    style={{ borderColor: tier.color, color: tier.color, background: `${tier.color}15` }}
                  >
                    {tier.name} — {tier.price}
                  </Badge>
                </div>

                <div className="space-y-3 mb-6">
                  {tier.features.map((feature, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <CheckCircle2 className="h-4 w-4" style={{ color: '#10B981' }} />
                      <span className="text-sm" style={{ color: '#CBD5E1' }}>{feature}</span>
                    </div>
                  ))}
                </div>

                <div className="flex gap-3">
                  <Button className="text-xs" style={{ background: '#3B82F6' }}>
                    Upgrade Plan
                  </Button>
                  <Button variant="outline" className="text-xs" style={{ borderColor: 'rgba(148, 163, 184, 0.2)', color: '#94A3B8' }}>
                    Cancel Subscription
                  </Button>
                </div>
              </Card>

              {/* Usage Meters */}
              <Card className="p-6 border-0" style={{ background: '#151E32' }}>
                <div className="text-sm font-medium mb-4" style={{ color: '#F1F5F9' }}>Usage This Period</div>
                {[
                  { label: 'AI Requests', used: 234, limit: 500, color: '#8B5CF6' },
                  { label: 'Dashboards', used: 3, limit: 10, color: '#06B6D4' },
                  { label: 'Storage', used: 12, limit: 50, color: '#10B981', unit: 'GB' },
                ].map((meter, i) => (
                  <div key={i} className="mb-4">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-xs" style={{ color: '#94A3B8' }}>{meter.label}</span>
                      <span className="text-xs" style={{ color: '#64748B' }}>
                        {meter.used}{meter.unit || ''} / {meter.limit}{meter.unit || ''}
                      </span>
                    </div>
                    <div className="w-full h-2 rounded-full" style={{ background: '#1E293B' }}>
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${Math.min((meter.used / meter.limit) * 100, 100)}%`,
                          background: meter.color,
                        }}
                      />
                    </div>
                  </div>
                ))}
              </Card>
            </div>
          )}

          {/* Security Tab */}
          {activeTab === 'security' && (
            <div>
              <h2 className="text-lg font-semibold mb-1" style={{ color: '#F1F5F9' }}>Security</h2>
              <p className="text-sm mb-6" style={{ color: '#94A3B8' }}>Manage your account security settings</p>

              {/* Two-Factor Authentication */}
              <Card className="p-6 mb-4 border-0" style={{ background: '#151E32' }}>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg" style={{ background: 'rgba(139, 92, 246, 0.1)' }}>
                      <Smartphone className="h-5 w-5" style={{ color: '#8B5CF6' }} />
                    </div>
                    <div>
                      <div className="text-sm font-medium" style={{ color: '#F1F5F9' }}>Two-Factor Authentication</div>
                      <div className="text-xs" style={{ color: '#94A3B8' }}>Add an extra layer of security</div>
                    </div>
                  </div>
                  {twoFAStatus?.enabled ? (
                    <Badge variant="outline" className="text-xs" style={{ borderColor: '#10B981', color: '#10B981', background: '#10B98115' }}>
                      <CheckCircle2 className="h-3 w-3 mr-1" />
                      Enabled
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="text-xs" style={{ borderColor: '#64748B', color: '#64748B', background: '#64748B15' }}>
                      Disabled
                    </Badge>
                  )}
                </div>

                {twoFactorStep === 'idle' && !twoFAStatus?.enabled && (
                  <div>
                    <p className="text-xs mb-4" style={{ color: '#94A3B8' }}>
                      When enabled, you'll need to enter a code from your authenticator app each time you log in.
                    </p>
                    <Button
                      onClick={handleSetup2FA}
                      disabled={false}
                      className="text-xs gap-2"
                      style={{ background: '#8B5CF6' }}
                    >
                      <Loader2 className="h-3 w-3" />
                      Enable 2FA
                    </Button>
                  </div>
                )}

                {twoFactorStep === 'idle' && twoFAStatus?.enabled && (
                  <div>
                    <p className="text-xs mb-4" style={{ color: '#94A3B8' }}>
                      2FA is currently enabled. To disable it, enter your 6-digit code.
                    </p>
                    <div className="flex items-center gap-3">
                      <Input
                        value={totpCode}
                        onChange={e => setTotpCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                        placeholder="000000"
                        className="h-9 w-32 text-center text-sm font-mono"
                        style={{ background: '#1E293B', borderColor: 'rgba(148, 163, 184, 0.2)', color: '#F1F5F9' }}
                      />
                      <Button
                        onClick={handleDisable2FA}
                        disabled={totpCode.length !== 6 || disable2FAMutation.isPending}
                        variant="outline"
                        className="text-xs"
                        style={{ borderColor: '#F43F5E', color: '#F43F5E' }}
                      >
                        {disable2FAMutation.isPending && <Loader2 className="h-3 w-3 animate-spin mr-1" />}
                        Disable 2FA
                      </Button>
                    </div>
                  </div>
                )}

                {twoFactorStep === 'setup' && (
                  <div>
                    <p className="text-xs mb-4" style={{ color: '#94A3B8' }}>
                      Scan the QR code with your authenticator app (Google Authenticator, Authy, etc.), then enter the 6-digit code.
                    </p>

                    {/* QR Code Display */}
                    <div className="flex items-center gap-6 mb-6">
                      <div
                        className="w-40 h-40 rounded-lg flex items-center justify-center"
                        style={{ background: '#fff', padding: 8 }}
                      >
                        {/* Simple QR code pattern */}
                        <div className="grid grid-cols-7 gap-0.5 w-full h-full">
                          {Array.from({ length: 49 }, (_, i) => (
                            <div
                              key={i}
                              className="rounded-sm"
                              style={{
                                background: [
                                  0,1,2,4,5,6,
                                  7,13,
                                  14,16,18,20,
                                  21,22,23,25,27,
                                  28,32,
                                  35,37,39,40,41,
                                  42,43,45,46,48
                                ].includes(i) ? '#000' : '#fff',
                              }}
                            />
                          ))}
                        </div>
                      </div>
                      <div>
                        <div className="text-xs mb-2" style={{ color: '#94A3B8' }}>Secret Key (manual entry)</div>
                        <div className="flex items-center gap-2">
                          <code
                            className="text-xs font-mono px-3 py-1.5 rounded"
                            style={{ background: '#1E293B', color: '#F1F5F9' }}
                          >
                            {totpSecret}
                          </code>
                          <button
                            onClick={() => {
                              navigator.clipboard.writeText(totpSecret);
                              toast({ title: 'Copied', description: 'Secret key copied to clipboard' });
                            }}
                            className="p-1.5 rounded"
                            style={{ color: '#64748B' }}
                          >
                            <Copy className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <Input
                        value={totpCode}
                        onChange={e => setTotpCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                        placeholder="Enter 6-digit code"
                        className="h-9 w-40 text-sm font-mono"
                        style={{ background: '#1E293B', borderColor: 'rgba(148, 163, 184, 0.2)', color: '#F1F5F9' }}
                      />
                      <Button
                        onClick={handleVerify2FA}
                        disabled={totpCode.length !== 6 || verify2FAMutation.isPending}
                        className="text-xs gap-2"
                        style={{ background: '#10B981' }}
                      >
                        {verify2FAMutation.isPending && <Loader2 className="h-3 w-3 animate-spin" />}
                        Verify & Enable
                      </Button>
                      <Button
                        variant="ghost"
                        onClick={() => { setTwoFactorStep('idle'); setTotpCode(''); }}
                        className="text-xs"
                        style={{ color: '#94A3B8' }}
                      >
                        Cancel
                      </Button>
                    </div>
                  </div>
                )}
              </Card>

              {/* Change Password */}
              <Card className="p-6 border-0" style={{ background: '#151E32' }}>
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2 rounded-lg" style={{ background: 'rgba(59, 130, 246, 0.1)' }}>
                    <Shield className="h-5 w-5" style={{ color: '#3B82F6' }} />
                  </div>
                  <div>
                    <div className="text-sm font-medium" style={{ color: '#F1F5F9' }}>Change Password</div>
                    <div className="text-xs" style={{ color: '#94A3B8' }}>Update your password regularly</div>
                  </div>
                </div>

                <div className="space-y-3">
                  <Input
                    type="password"
                    placeholder="Current password"
                    className="h-9 text-sm"
                    style={{ background: '#1E293B', borderColor: 'rgba(148, 163, 184, 0.2)', color: '#F1F5F9' }}
                  />
                  <Input
                    type="password"
                    placeholder="New password"
                    className="h-9 text-sm"
                    style={{ background: '#1E293B', borderColor: 'rgba(148, 163, 184, 0.2)', color: '#F1F5F9' }}
                  />
                  <Input
                    type="password"
                    placeholder="Confirm new password"
                    className="h-9 text-sm"
                    style={{ background: '#1E293B', borderColor: 'rgba(148, 163, 184, 0.2)', color: '#F1F5F9' }}
                  />
                  <Button className="text-xs" style={{ background: '#3B82F6' }}>
                    Update Password
                  </Button>
                </div>
              </Card>
            </div>
          )}

          {/* Notifications Tab */}
          {activeTab === 'notifications' && (
            <div>
              <h2 className="text-lg font-semibold mb-1" style={{ color: '#F1F5F9' }}>Notifications</h2>
              <p className="text-sm mb-6" style={{ color: '#94A3B8' }}>Choose how you want to be notified</p>

              <Card className="p-6 border-0" style={{ background: '#151E32' }}>
                {[
                  { id: 'email', label: 'Email Notifications', description: 'Receive updates via email', icon: <Bell className="h-4 w-4" /> },
                  { id: 'browser', label: 'Browser Notifications', description: 'Show desktop notifications', icon: <Monitor className="h-4 w-4" /> },
                  { id: 'security', label: 'Security Alerts', description: 'Get notified about security events', icon: <Shield className="h-4 w-4" /> },
                  { id: 'marketing', label: 'Marketing Updates', description: 'Product news and feature announcements', icon: <Bell className="h-4 w-4" /> },
                ].map(item => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between py-4"
                    style={{ borderBottom: '1px solid rgba(148, 163, 184, 0.05)' }}
                  >
                    <div className="flex items-center gap-3">
                      <div style={{ color: '#94A3B8' }}>{item.icon}</div>
                      <div>
                        <div className="text-sm" style={{ color: '#F1F5F9' }}>{item.label}</div>
                        <div className="text-xs" style={{ color: '#64748B' }}>{item.description}</div>
                      </div>
                    </div>
                    <Switch
                      checked={notifications[item.id as keyof typeof notifications]}
                      onCheckedChange={(checked) =>
                        setNotifications(prev => ({ ...prev, [item.id]: checked }))
                      }
                    />
                  </div>
                ))}
              </Card>
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
