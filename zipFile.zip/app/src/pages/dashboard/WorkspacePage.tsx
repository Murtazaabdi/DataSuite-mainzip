import { useState } from 'react';
import {
  Plus,
  FileText,
  Trash2,
  Clock,
  FilePlus,
  LayoutGrid,
  List,
  Save,
  Bold,
  Italic,
  Heading1,
  Heading2,
  ListOrdered,
  CheckSquare,
  Code,
  Quote,
  Image,
  Table2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';

interface Document {
  id: string;
  title: string;
  content: string;
  lastModified: string;
  type: 'document' | 'notebook' | 'template';
}

const sampleDocs: Document[] = [
  {
    id: '1',
    title: 'Q3 Sales Analysis Plan',
    content: `# Q3 Sales Analysis Plan

## Objective
Analyze Q3 sales performance across all regions and identify growth opportunities for Q4.

## Key Metrics
- Total Revenue vs Target
- Customer Acquisition Cost
- Lifetime Value Analysis
- Churn Rate by Segment

## Data Sources
1. CRM Database (sales_data table)
2. Marketing Analytics Platform
3. Customer Feedback Surveys

## Timeline
| Phase | Start | End | Owner |
|-------|-------|-----|-------|
| Data Collection | Oct 1 | Oct 7 | Data Team |
| Analysis | Oct 8 | Oct 14 | Analysts |
| Reporting | Oct 15 | Oct 21 | BI Team |
| Presentation | Oct 22 | Oct 28 | Leadership |

## Action Items
- [ ] Pull Q3 revenue data from warehouse
- [ ] Build comparison dashboard
- [ ] Schedule stakeholder review
- [ ] Prepare executive summary

## Notes
Focus on underperforming regions. North America missed target by 8%.`,
    lastModified: '2 hours ago',
    type: 'document',
  },
  {
    id: '2',
    title: 'Customer Segmentation Study',
    content: `# Customer Segmentation Study

## Methodology
Using K-means clustering on RFM (Recency, Frequency, Monetary) metrics.

## Segments Identified

### 1. Champions (15%)
- High RFM scores
- Most valuable customers
- **Action:** VIP program, early access

### 2. Loyal Customers (25%)
- High frequency, moderate spend
- Regular purchasers
- **Action:** Loyalty rewards, referrals

### 3. Potential Loyalists (20%)
- Recent customers, low frequency
- Growth potential
- **Action:** Onboarding, engagement campaigns

### 4. At Risk (18%)
- Declining recency
- Previously active
- **Action:** Win-back campaigns

### 5. Hibernating (22%)
- Low across all metrics
- **Action:** Re-engagement or deprioritize

## Next Steps
Run the segmentation model monthly and track segment migration patterns.`,
    lastModified: '1 day ago',
    type: 'notebook',
  },
  {
    id: '3',
    title: 'Data Pipeline Architecture',
    content: `# Data Pipeline Architecture

## Overview
Modern ELT pipeline using cloud-native tools.

## Architecture Diagram

\`\`\`
[Sources] → [Ingestion] → [Storage] → [Transform] → [Serve]
   ↓            ↓            ↓           ↓          ↓
 APIs       Kafka       Data Lake    dbt       Warehouse
 DBs        Airflow     S3/Blob      Spark     BI Tools
 Files      Fivetran    Delta Lake   SQL       ML Platform
\`\`\`

## Components

### Ingestion Layer
- **Apache Kafka:** Real-time streaming
- **Apache Airflow:** Orchestration
- **Fivetran:** SaaS connectors

### Storage Layer
- **Data Lake:** Raw data in Parquet format
- **Delta Lake:** ACID transactions
- **Retention:** 7 years hot, 30 years cold

### Transformation Layer
- **dbt:** SQL-based transformations
- **Spark:** Complex processing
- **Great Expectations:** Data quality

### Serving Layer
- **Snowflake:** Primary warehouse
- **Redis:** Caching layer
- **API Gateway:** Data access

## Monitoring
- Data freshness alerts (< 1 hour SLA)
- Quality score tracking (> 99%)
- Pipeline success rate (> 99.5%)`,
    lastModified: '3 days ago',
    type: 'document',
  },
];

const templates = [
  { label: 'Analysis Plan', icon: <FileText className="h-4 w-4" /> },
  { label: 'Weekly Report', icon: <ListOrdered className="h-4 w-4" /> },
  { label: 'Project Spec', icon: <CheckSquare className="h-4 w-4" /> },
  { label: 'Meeting Notes', icon: <Quote className="h-4 w-4" /> },
];

export default function WorkspacePage() {
  const [documents, setDocuments] = useState<Document[]>(sampleDocs);
  const [activeDocId, setActiveDocId] = useState<string>('1');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('list');
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState('');

  const activeDoc = documents.find(d => d.id === activeDocId);

  const createDoc = (type: 'document' | 'notebook') => {
    const newDoc: Document = {
      id: Date.now().toString(),
      title: `Untitled ${type === 'notebook' ? 'Notebook' : 'Document'}`,
      content: `# New ${type === 'notebook' ? 'Notebook' : 'Document'}\n\nStart writing...`,
      lastModified: 'Just now',
      type,
    };
    setDocuments(prev => [newDoc, ...prev]);
    setActiveDocId(newDoc.id);
    setIsEditing(true);
    setEditContent(newDoc.content);
  };

  const deleteDoc = (id: string) => {
    setDocuments(prev => prev.filter(d => d.id !== id));
    if (activeDocId === id) {
      const remaining = documents.filter(d => d.id !== id);
      if (remaining.length > 0) setActiveDocId(remaining[0].id);
    }
  };

  const saveDoc = () => {
    if (activeDoc) {
      setDocuments(prev =>
        prev.map(d =>
          d.id === activeDocId ? { ...d, content: editContent, lastModified: 'Just now' } : d
        )
      );
      setIsEditing(false);
    }
  };

  const formatContent = (content: string) => {
    return content
      .replace(/^# (.*$)/gim, '<h1 class="text-2xl font-bold mb-4" style="color:#F1F5F9">$1</h1>')
      .replace(/^## (.*$)/gim, '<h2 class="text-xl font-semibold mt-6 mb-3" style="color:#F1F5F9">$1</h2>')
      .replace(/^### (.*$)/gim, '<h3 class="text-lg font-semibold mt-4 mb-2" style="color:#F1F5F9">$1</h3>')
      .replace(/\*\*(.*?)\*\*/g, '<strong style="color:#F1F5F9">$1</strong>')
      .replace(/\*(.*?)\*/g, '<em style="color:#94A3B8">$1</em>')
      .replace(/^- \[ \] (.*$)/gim, '<div class="flex items-center gap-2 my-1"><div class="w-4 h-4 rounded border" style="border-color:rgba(148,163,184,0.3)"></div><span style="color:#CBD5E1">$1</span></div>')
      .replace(/^- \[x\] (.*$)/gim, '<div class="flex items-center gap-2 my-1"><div class="w-4 h-4 rounded flex items-center justify-center" style="background:#10B981"><svg class="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg></div><span style="color:#CBD5E1;text-decoration:line-through">$1</span></div>')
      .replace(/^- (.*$)/gim, '<li class="ml-4 my-1" style="color:#CBD5E1;list-style-type:disc">$1</li>')
      .replace(/^\d+\. (.*$)/gim, '<li class="ml-4 my-1" style="color:#CBD5E1;list-style-type:decimal">$1</li>')
      .replace(/\`\`\`(\w+)?\n([\s\S]*?)\`\`\`/g, '<pre class="bg-[#0B1120] border rounded-lg p-4 my-4 overflow-x-auto" style="border-color:rgba(148,163,184,0.1)"><code class="text-xs font-mono" style="color:#06B6D4">$2</code></pre>')
      .replace(/`([^`]+)`/g, '<code class="px-1.5 py-0.5 rounded text-sm font-mono" style="background:#1E293B;color:#06B6D4">$1</code>')
      .replace(/\n/g, '<br>');
  };

  return (
    <div className="h-full flex">
      {/* Document List */}
      <div
        className="w-72 border-r flex flex-col"
        style={{ background: '#151E32', borderColor: 'rgba(148, 163, 184, 0.1)' }}
      >
        {/* Toolbar */}
        <div className="p-3">
          <div className="flex items-center gap-2 mb-3">
            <Input
              placeholder="Search documents..."
              className="h-8 text-xs"
              style={{ background: '#1E293B', borderColor: 'rgba(148, 163, 184, 0.2)', color: '#F1F5F9' }}
            />
          </div>
          <div className="flex gap-2">
            <Button
              size="sm"
              className="flex-1 gap-1 text-xs h-7"
              style={{ background: '#3B82F6', color: '#fff' }}
              onClick={() => createDoc('document')}
            >
              <Plus className="h-3 w-3" />
              New Doc
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="flex-1 gap-1 text-xs h-7"
              style={{ borderColor: 'rgba(148, 163, 184, 0.2)', color: '#94A3B8' }}
              onClick={() => createDoc('notebook')}
            >
              <FilePlus className="h-3 w-3" />
              Notebook
            </Button>
          </div>
        </div>

        <div
          className="mx-3 mb-2"
          style={{ height: 1, background: 'rgba(148, 163, 184, 0.1)' }}
        />

        {/* Document List */}
        <ScrollArea className="flex-1">
          <div className="px-3 py-2">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium" style={{ color: '#64748B' }}>DOCUMENTS</span>
              <div className="flex gap-1">
                <button
                  onClick={() => setViewMode('list')}
                  className="p-1 rounded"
                  style={{ color: viewMode === 'list' ? '#F1F5F9' : '#64748B', background: viewMode === 'list' ? '#243447' : 'transparent' }}
                >
                  <List className="h-3 w-3" />
                </button>
                <button
                  onClick={() => setViewMode('grid')}
                  className="p-1 rounded"
                  style={{ color: viewMode === 'grid' ? '#F1F5F9' : '#64748B', background: viewMode === 'grid' ? '#243447' : 'transparent' }}
                >
                  <LayoutGrid className="h-3 w-3" />
                </button>
              </div>
            </div>

            {documents.map(doc => (
              <div
                key={doc.id}
                onClick={() => {
                  setActiveDocId(doc.id);
                  setIsEditing(false);
                }}
                className="flex items-center gap-2 px-2 py-2 rounded cursor-pointer group"
                style={{
                  background: activeDocId === doc.id ? '#243447' : 'transparent',
                  borderLeft: activeDocId === doc.id ? '2px solid #3B82F6' : '2px solid transparent',
                }}
                onMouseEnter={e => {
                  if (activeDocId !== doc.id) e.currentTarget.style.background = '#1E293B';
                }}
                onMouseLeave={e => {
                  if (activeDocId !== doc.id) e.currentTarget.style.background = 'transparent';
                }}
              >
                <FileText className="h-4 w-4 flex-shrink-0" style={{ color: doc.type === 'notebook' ? '#8B5CF6' : '#3B82F6' }} />
                <div className="flex-1 min-w-0">
                  <div className="text-xs truncate" style={{ color: activeDocId === doc.id ? '#F1F5F9' : '#94A3B8' }}>
                    {doc.title}
                  </div>
                  <div className="flex items-center gap-1 text-xs" style={{ color: '#64748B' }}>
                    <Clock className="h-2.5 w-2.5" />
                    {doc.lastModified}
                  </div>
                </div>
                <button
                  onClick={(e) => { e.stopPropagation(); deleteDoc(doc.id); }}
                  className="opacity-0 group-hover:opacity-100 p-1 rounded"
                >
                  <Trash2 className="h-3 w-3" style={{ color: '#64748B' }} />
                </button>
              </div>
            ))}
          </div>

          {/* Templates */}
          <div className="px-3 py-2">
            <div className="text-xs font-medium mb-2" style={{ color: '#64748B' }}>TEMPLATES</div>
            {templates.map((t, i) => (
              <button
                key={i}
                className="w-full flex items-center gap-2 px-2 py-1.5 rounded text-left"
                style={{ color: '#94A3B8' }}
                onMouseEnter={e => { e.currentTarget.style.background = '#243447'; }}
                onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; }}
              >
                {t.icon}
                <span className="text-xs">{t.label}</span>
              </button>
            ))}
          </div>
        </ScrollArea>
      </div>

      {/* Document Editor/Viewer */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {activeDoc && (
          <>
            {/* Toolbar */}
            <div
              className="flex items-center justify-between px-4 py-2 border-b"
              style={{ background: '#151E32', borderColor: 'rgba(148, 163, 184, 0.1)' }}
            >
              <div className="flex items-center gap-3">
                <Input
                  value={activeDoc.title}
                  className="h-8 w-64 text-sm font-medium bg-transparent border-0"
                  style={{ color: '#F1F5F9' }}
                />
              </div>
              <div className="flex items-center gap-2">
                {isEditing ? (
                  <>
                    <Button size="sm" onClick={saveDoc} className="gap-1 text-xs" style={{ background: '#10B981', color: '#fff' }}>
                      <Save className="h-3.5 w-3.5" />
                      Save
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => setIsEditing(false)} className="text-xs" style={{ color: '#94A3B8' }}>
                      Cancel
                    </Button>
                  </>
                ) : (
                  <Button size="sm" variant="ghost" onClick={() => { setIsEditing(true); setEditContent(activeDoc.content); }} className="gap-1 text-xs" style={{ color: '#94A3B8' }}>
                    Edit
                  </Button>
                )}
              </div>
            </div>

            {/* Formatting Toolbar */}
            {isEditing && (
              <div
                className="flex items-center gap-1 px-4 py-1.5 border-b"
                style={{ background: '#0B1120', borderColor: 'rgba(148, 163, 184, 0.1)' }}
              >
                {[
                  { icon: <Bold className="h-3.5 w-3.5" />, label: 'Bold' },
                  { icon: <Italic className="h-3.5 w-3.5" />, label: 'Italic' },
                  { icon: <Heading1 className="h-3.5 w-3.5" />, label: 'H1' },
                  { icon: <Heading2 className="h-3.5 w-3.5" />, label: 'H2' },
                  { icon: <ListOrdered className="h-3.5 w-3.5" />, label: 'List' },
                  { icon: <CheckSquare className="h-3.5 w-3.5" />, label: 'Todo' },
                  { icon: <Code className="h-3.5 w-3.5" />, label: 'Code' },
                  { icon: <Quote className="h-3.5 w-3.5" />, label: 'Quote' },
                  { icon: <Image className="h-3.5 w-3.5" />, label: 'Image' },
                  { icon: <Table2 className="h-3.5 w-3.5" />, label: 'Table' },
                ].map((tool, i) => (
                  <button
                    key={i}
                    className="p-1.5 rounded"
                    style={{ color: '#94A3B8' }}
                    title={tool.label}
                    onMouseEnter={e => { e.currentTarget.style.background = '#243447'; }}
                    onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; }}
                  >
                    {tool.icon}
                  </button>
                ))}
              </div>
            )}

            {/* Content */}
            <ScrollArea className="flex-1">
              <div className="max-w-3xl mx-auto py-8 px-8">
                {isEditing ? (
                  <textarea
                    value={editContent}
                    onChange={e => setEditContent(e.target.value)}
                    className="w-full min-h-[600px] bg-transparent outline-none resize-none font-mono text-sm leading-relaxed"
                    style={{ color: '#F1F5F9' }}
                  />
                ) : (
                  <div
                    className="prose prose-invert max-w-none"
                    dangerouslySetInnerHTML={{ __html: formatContent(activeDoc.content) }}
                  />
                )}
              </div>
            </ScrollArea>
          </>
        )}
      </div>
    </div>
  );
}
