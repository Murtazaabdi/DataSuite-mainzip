import { useState } from 'react';
import Editor from '@monaco-editor/react';
import {
  Play,
  Save,
  ChevronDown,
  ChevronRight,
  Table,
  Clock,
  Rows3,
  CheckCircle2,
  AlertCircle,
  Star,
  History,
  FileText,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { trpc } from '@/providers/trpc';

interface QueryResult {
  columns: string[];
  rows: Record<string, any>[];
  rowCount: number;
  executionTime: number;
  message?: string;
}

const sampleTables = [
  {
    name: 'sales_data',
    columns: [
      { name: 'id', type: 'INT', key: true },
      { name: 'date', type: 'DATE' },
      { name: 'region', type: 'VARCHAR(50)' },
      { name: 'product_line', type: 'VARCHAR(100)' },
      { name: 'revenue', type: 'DECIMAL(12,2)' },
      { name: 'profit', type: 'DECIMAL(12,2)' },
      { name: 'margin_pct', type: 'DECIMAL(5,2)' },
      { name: 'quantity', type: 'INT' },
    ],
  },
  {
    name: 'customers',
    columns: [
      { name: 'id', type: 'INT', key: true },
      { name: 'name', type: 'VARCHAR(200)' },
      { name: 'email', type: 'VARCHAR(255)' },
      { name: 'tier', type: 'VARCHAR(50)' },
      { name: 'created_at', type: 'TIMESTAMP' },
      { name: 'region', type: 'VARCHAR(50)' },
    ],
  },
  {
    name: 'products',
    columns: [
      { name: 'id', type: 'INT', key: true },
      { name: 'name', type: 'VARCHAR(200)' },
      { name: 'category', type: 'VARCHAR(100)' },
      { name: 'price', type: 'DECIMAL(10,2)' },
      { name: 'stock', type: 'INT' },
    ],
  },
];

const sampleQueries = [
  { name: 'Revenue by Region', query: 'SELECT region, SUM(revenue) as total_revenue, AVG(margin_pct) as avg_margin FROM sales_data GROUP BY region ORDER BY total_revenue DESC;' },
  { name: 'Top Customers', query: 'SELECT name, email, tier FROM customers WHERE tier IN (\'enterprise\', \'data_scientist\') ORDER BY created_at DESC LIMIT 20;' },
  { name: 'Product Inventory', query: 'SELECT name, category, price, stock FROM products WHERE stock < 100 ORDER BY stock ASC;' },
];

export default function SQLWorkbenchPage() {
  const [query, setQuery] = useState('SELECT region,\n       SUM(revenue) as total_revenue,\n       AVG(margin_pct) as avg_margin\nFROM sales_data\nWHERE date >= \'2024-01-01\'\nGROUP BY region\nORDER BY total_revenue DESC;');
  const [result, setResult] = useState<QueryResult | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [expandedTables, setExpandedTables] = useState<string[]>(['sales_data']);
  const [activeTab, setActiveTab] = useState<'results' | 'history' | 'saved'>('results');
  const [queryHistory, setQueryHistory] = useState<Array<{ query: string; time: string; duration: number }>>([]);
  const executeMutation = trpc.sql.execute.useMutation();

  const toggleTable = (name: string) => {
    setExpandedTables(prev =>
      prev.includes(name) ? prev.filter(n => n !== name) : [...prev, name]
    );
  };

  const handleRun = async () => {
    if (!query.trim()) return;
    setIsRunning(true);
    setActiveTab('results');

    try {
      const res = await executeMutation.mutateAsync({ query });
      if (res.success) {
        setResult({
          columns: res.columns,
          rows: res.rows,
          rowCount: res.rowCount,
          executionTime: res.executionTime,
          message: res.message,
        });
        setQueryHistory(prev => [{
          query,
          time: new Date().toLocaleTimeString(),
          duration: res.executionTime,
        }, ...prev].slice(0, 50));
      }
    } catch (err) {
      setResult({
        columns: [],
        rows: [],
        rowCount: 0,
        executionTime: 0,
        message: 'Error: ' + (err instanceof Error ? err.message : 'Query execution failed'),
      });
    } finally {
      setIsRunning(false);
    }
  };

  const insertTableQuery = (tableName: string) => {
    setQuery(`SELECT * FROM ${tableName} LIMIT 100;`);
  };

  return (
    <div className="h-full flex flex-col">
      {/* Toolbar */}
      <div
        className="flex items-center justify-between px-4 py-2 border-b"
        style={{ background: '#151E32', borderColor: 'rgba(148, 163, 184, 0.1)' }}
      >
        <div className="flex items-center gap-3">
          <div
            className="flex items-center gap-2 px-3 py-1.5 rounded-md text-xs"
            style={{ background: '#1E293B', color: '#94A3B8', border: '1px solid rgba(148, 163, 184, 0.2)' }}
          >
            <div className="w-2 h-2 rounded-full" style={{ background: '#10B981' }} />
            <span>User Warehouse</span>
          </div>
          <div
            className="text-xs px-2 py-1 rounded"
            style={{ background: '#1E293B', color: '#64748B' }}
          >
            schema: user_{String((query?.length || 0) % 99999).padStart(5, '0')}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button size="sm" onClick={handleRun} disabled={isRunning} className="gap-1.5 text-white" style={{ background: '#10B981' }}>
            <Play className="h-3.5 w-3.5" />
            {isRunning ? 'Running...' : 'Run'}
          </Button>
          <Button variant="ghost" size="sm" className="gap-1" style={{ color: '#94A3B8' }}>
            <Save className="h-3.5 w-3.5" />
            <span className="text-xs">Save</span>
          </Button>
        </div>
      </div>

      {/* Main Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Schema Browser */}
        <div
          className="w-56 border-r flex flex-col"
          style={{ background: '#151E32', borderColor: 'rgba(148, 163, 184, 0.1)' }}
        >
          <div
            className="px-3 py-2 border-b flex items-center gap-2"
            style={{ borderColor: 'rgba(148, 163, 184, 0.1)' }}
          >
            <Input
              placeholder="Search tables..."
              className="h-7 text-xs"
              style={{ background: '#1E293B', borderColor: 'rgba(148, 163, 184, 0.2)', color: '#F1F5F9' }}
            />
          </div>
          <ScrollArea className="flex-1">
            <div className="px-2 py-2">
              <div className="text-xs font-medium mb-2 px-2" style={{ color: '#64748B' }}>TABLES</div>
              {sampleTables.map(table => (
                <div key={table.name}>
                  <button
                    onClick={() => toggleTable(table.name)}
                    className="w-full flex items-center gap-2 px-2 py-1.5 rounded text-left"
                    style={{ color: '#F1F5F9' }}
                    onMouseEnter={e => { e.currentTarget.style.background = '#243447'; }}
                    onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; }}
                  >
                    {expandedTables.includes(table.name) ?
                      <ChevronDown className="h-3 w-3" style={{ color: '#64748B' }} /> :
                      <ChevronRight className="h-3 w-3" style={{ color: '#64748B' }} />
                    }
                    <Table className="h-4 w-4" style={{ color: '#10B981' }} />
                    <span className="text-xs">{table.name}</span>
                  </button>
                  {expandedTables.includes(table.name) && (
                    <div className="ml-6">
                      {table.columns.map(col => (
                        <div
                          key={col.name}
                          className="flex items-center gap-2 px-2 py-1"
                          style={{ color: '#94A3B8' }}
                        >
                          {col.key && <div className="w-2 h-2 rounded-full" style={{ background: '#F59E0B' }} />}
                          <span className="text-xs">{col.name}</span>
                          <span className="text-xs ml-auto" style={{ color: '#64748B' }}>{col.type}</span>
                        </div>
                      ))}
                      <button
                        onClick={() => insertTableQuery(table.name)}
                        className="text-xs px-2 py-1 mt-1 rounded"
                        style={{ color: '#3B82F6' }}
                        onMouseEnter={e => { e.currentTarget.style.background = 'rgba(59, 130, 246, 0.1)'; }}
                        onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; }}
                      >
                        SELECT * FROM {table.name}
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div
              className="mx-3 my-2"
              style={{ height: 1, background: 'rgba(148, 163, 184, 0.1)' }}
            />

            <div className="px-2 py-2">
              <div className="text-xs font-medium mb-2 px-2" style={{ color: '#64748B' }}>SAVED QUERIES</div>
              {sampleQueries.map((sq, i) => (
                <button
                  key={i}
                  onClick={() => setQuery(sq.query)}
                  className="w-full flex items-center gap-2 px-2 py-1.5 rounded text-left"
                  style={{ color: '#94A3B8' }}
                  onMouseEnter={e => { e.currentTarget.style.background = '#243447'; }}
                  onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; }}
                >
                  <Star className="h-3 w-3" style={{ color: '#F59E0B' }} />
                  <span className="text-xs truncate">{sq.name}</span>
                </button>
              ))}
            </div>
          </ScrollArea>
        </div>

        {/* Editor & Results */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Query Editor */}
          <div className="flex-1 min-h-0">
            <Editor
              height="100%"
              language="sql"
              value={query}
              onChange={(value) => value !== undefined && setQuery(value)}
              theme="vs-dark"
              options={{
                fontSize: 14,
                fontFamily: 'JetBrains Mono, monospace',
                minimap: { enabled: false },
                lineNumbers: 'on',
                folding: true,
                padding: { top: 16 },
                scrollBeyondLastLine: false,
              }}
            />
          </div>

          {/* Results Panel */}
          <div
            className="border-t flex flex-col"
            style={{ borderColor: 'rgba(148, 163, 184, 0.1)', height: 250 }}
          >
            {/* Tabs */}
            <div className="flex items-center border-b px-4" style={{ borderColor: 'rgba(148, 163, 184, 0.1)', background: '#151E32' }}>
              {[
                { id: 'results' as const, label: 'Results', icon: <Rows3 className="h-3.5 w-3.5" /> },
                { id: 'history' as const, label: 'History', icon: <History className="h-3.5 w-3.5" /> },
                { id: 'saved' as const, label: 'Saved', icon: <FileText className="h-3.5 w-3.5" /> },
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className="flex items-center gap-1.5 px-3 py-2 text-xs transition-colors"
                  style={{
                    color: activeTab === tab.id ? '#F1F5F9' : '#64748B',
                    borderBottom: activeTab === tab.id ? '2px solid #3B82F6' : '2px solid transparent',
                  }}
                >
                  {tab.icon}
                  {tab.label}
                </button>
              ))}
              {result && (
                <div className="ml-auto flex items-center gap-3 text-xs" style={{ color: '#64748B' }}>
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {result.executionTime.toFixed(0)}ms
                  </span>
                  <span>{result.rowCount} rows</span>
                </div>
              )}
            </div>

            {/* Content */}
            <ScrollArea className="flex-1" style={{ background: '#0B1120' }}>
              {activeTab === 'results' && (
                <div>
                  {result?.message && !result.columns.length && (
                    <div className="p-4 flex items-center gap-2">
                      {result.message.includes('Error') ?
                        <AlertCircle className="h-4 w-4" style={{ color: '#F43F5E' }} /> :
                        <CheckCircle2 className="h-4 w-4" style={{ color: '#10B981' }} />
                      }
                      <span className="text-sm" style={{ color: result.message.includes('Error') ? '#F43F5E' : '#10B981' }}>
                        {result.message}
                      </span>
                    </div>
                  )}
                  {result && result.columns.length > 0 && (
                    <table className="w-full text-xs">
                      <thead>
                        <tr style={{ background: '#1E293B' }}>
                          {result.columns.map(col => (
                            <th key={col} className="text-left px-3 py-2 font-medium" style={{ color: '#94A3B8', borderBottom: '1px solid rgba(148, 163, 184, 0.2)' }}>
                              {col}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {result.rows.map((row, i) => (
                          <tr
                            key={i}
                            style={{ borderBottom: '1px solid rgba(148, 163, 184, 0.05)' }}
                            onMouseEnter={e => { e.currentTarget.style.background = '#151E32'; }}
                            onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; }}
                          >
                            {result.columns.map(col => (
                              <td key={col} className="px-3 py-2" style={{ color: '#F1F5F9' }}>
                                {String(row[col] ?? '')}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                  {!result && (
                    <div className="flex flex-col items-center justify-center py-12" style={{ color: '#64748B' }}>
                      <Rows3 className="h-8 w-8 mb-3" />
                      <p className="text-sm">Run a query to see results</p>
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'history' && (
                <div className="p-2">
                  {queryHistory.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-12" style={{ color: '#64748B' }}>
                      <History className="h-8 w-8 mb-3" />
                      <p className="text-sm">Query history will appear here</p>
                    </div>
                  ) : (
                    queryHistory.map((h, i) => (
                      <div
                        key={i}
                        onClick={() => setQuery(h.query)}
                        className="p-2 rounded cursor-pointer"
                        style={{ borderBottom: '1px solid rgba(148, 163, 184, 0.05)' }}
                        onMouseEnter={e => { e.currentTarget.style.background = '#151E32'; }}
                        onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; }}
                      >
                        <pre className="text-xs font-mono truncate" style={{ color: '#F1F5F9' }}>{h.query}</pre>
                        <div className="flex items-center gap-3 mt-1 text-xs" style={{ color: '#64748B' }}>
                          <span>{h.time}</span>
                          <span>{h.duration.toFixed(0)}ms</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {activeTab === 'saved' && (
                <div className="p-4">
                  {sampleQueries.map((sq, i) => (
                    <div
                      key={i}
                      onClick={() => setQuery(sq.query)}
                      className="p-3 rounded-lg mb-2 cursor-pointer"
                      style={{ background: '#151E32', border: '1px solid rgba(148, 163, 184, 0.1)' }}
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <Star className="h-3.5 w-3.5" style={{ color: '#F59E0B' }} />
                        <span className="text-sm font-medium" style={{ color: '#F1F5F9' }}>{sq.name}</span>
                      </div>
                      <pre className="text-xs font-mono" style={{ color: '#94A3B8' }}>{sq.query}</pre>
                    </div>
                  ))}
                </div>
              )}
            </ScrollArea>
          </div>
        </div>
      </div>
    </div>
  );
}
