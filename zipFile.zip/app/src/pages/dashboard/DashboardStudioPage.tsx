import { useState } from 'react';
import {
  BarChart3,
  LineChart,
  PieChart,
  Activity,
  Table2,
  Plus,
  GripVertical,
  Trash2,
  Download,
  Eye,
  Save,
  TrendingUp,
  TrendingDown,
  Users,
  DollarSign,
  ShoppingCart,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import {
  LineChart as ReLineChart,
  Line,
  BarChart as ReBarChart,
  Bar,
  PieChart as RePieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area,
} from 'recharts';

const palette = ['#3B82F6', '#06B6D4', '#8B5CF6', '#10B981', '#F59E0B', '#F43F5E', '#EC4899', '#6366F1'];

const mockLineData = [
  { month: 'Jan', revenue: 120000, profit: 25000 },
  { month: 'Feb', revenue: 135000, profit: 33000 },
  { month: 'Mar', revenue: 148000, profit: 38000 },
  { month: 'Apr', revenue: 162000, profit: 44000 },
  { month: 'May', revenue: 155000, profit: 40000 },
  { month: 'Jun', revenue: 178000, profit: 53000 },
];

const mockBarData = [
  { region: 'North', sales: 450000, target: 400000 },
  { region: 'South', sales: 320000, target: 350000 },
  { region: 'East', sales: 380000, target: 360000 },
  { region: 'West', sales: 290000, target: 300000 },
];

const mockPieData = [
  { name: 'Electronics', value: 35 },
  { name: 'Software', value: 25 },
  { name: 'Services', value: 20 },
  { name: 'Support', value: 15 },
  { name: 'Other', value: 5 },
];

interface Widget {
  id: string;
  type: 'kpi' | 'line' | 'bar' | 'pie' | 'area' | 'table';
  title: string;
  x: number;
  y: number;
  w: number;
  h: number;
}

const widgetTypes = [
  { type: 'kpi' as const, label: 'KPI Card', icon: <Activity className="h-4 w-4" /> },
  { type: 'line' as const, label: 'Line Chart', icon: <LineChart className="h-4 w-4" /> },
  { type: 'bar' as const, label: 'Bar Chart', icon: <BarChart3 className="h-4 w-4" /> },
  { type: 'pie' as const, label: 'Pie Chart', icon: <PieChart className="h-4 w-4" /> },
  { type: 'area' as const, label: 'Area Chart', icon: <Activity className="h-4 w-4" /> },
  { type: 'table' as const, label: 'Data Table', icon: <Table2 className="h-4 w-4" /> },
];

const kpis = [
  { label: 'Total Revenue', value: '$1.24M', change: '+12.5%', positive: true, icon: <DollarSign className="h-5 w-5" /> },
  { label: 'Active Users', value: '8,420', change: '+5.2%', positive: true, icon: <Users className="h-5 w-5" /> },
  { label: 'Conversion Rate', value: '3.24%', change: '-0.8%', positive: false, icon: <ShoppingCart className="h-5 w-5" /> },
  { label: 'Avg Order Value', value: '$146', change: '+8.1%', positive: true, icon: <Activity className="h-5 w-5" /> },
];

export default function DashboardStudioPage() {
  const [widgets, setWidgets] = useState<Widget[]>([
    { id: '1', type: 'kpi', title: 'Key Metrics', x: 0, y: 0, w: 4, h: 1 },
    { id: '2', type: 'line', title: 'Revenue Trend', x: 0, y: 1, w: 2, h: 2 },
    { id: '3', type: 'bar', title: 'Sales by Region', x: 2, y: 1, w: 2, h: 2 },
    { id: '4', type: 'pie', title: 'Product Mix', x: 0, y: 3, w: 2, h: 2 },
    { id: '5', type: 'area', title: 'Growth Trajectory', x: 2, y: 3, w: 2, h: 2 },
  ]);
  const [selectedWidget, setSelectedWidget] = useState<string | null>(null);
  const [, setEditTitle] = useState('');

  const addWidget = (type: Widget['type']) => {
    const newWidget: Widget = {
      id: Date.now().toString(),
      type,
      title: type === 'kpi' ? 'KPI Card' : type === 'line' ? 'Line Chart' : type === 'bar' ? 'Bar Chart' : type === 'pie' ? 'Pie Chart' : type === 'area' ? 'Area Chart' : 'Data Table',
      x: 0,
      y: widgets.length,
      w: 2,
      h: 2,
    };
    setWidgets(prev => [...prev, newWidget]);
  };

  const removeWidget = (id: string) => {
    setWidgets(prev => prev.filter(w => w.id !== id));
    if (selectedWidget === id) setSelectedWidget(null);
  };

  const renderWidget = (widget: Widget) => {
    switch (widget.type) {
      case 'kpi':
        return (
          <div className="grid grid-cols-4 gap-4 p-4">
            {kpis.map((kpi, i) => (
              <div key={i} className="flex flex-col">
                <div className="flex items-center gap-2 mb-1">
                  <div className="p-1.5 rounded-md" style={{ background: `${kpi.positive ? '#10B981' : '#F43F5E'}15`, color: kpi.positive ? '#10B981' : '#F43F5E' }}>
                    {kpi.icon}
                  </div>
                </div>
                <span className="text-lg font-semibold" style={{ color: '#F1F5F9' }}>{kpi.value}</span>
                <span className="text-xs" style={{ color: '#94A3B8' }}>{kpi.label}</span>
                <div className="flex items-center gap-1 mt-1">
                  {kpi.positive ? <TrendingUp className="h-3 w-3" style={{ color: '#10B981' }} /> : <TrendingDown className="h-3 w-3" style={{ color: '#F43F5E' }} />}
                  <span className="text-xs" style={{ color: kpi.positive ? '#10B981' : '#F43F5E' }}>{kpi.change}</span>
                </div>
              </div>
            ))}
          </div>
        );
      case 'line':
        return (
          <ResponsiveContainer width="100%" height="100%">
            <ReLineChart data={mockLineData} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
              <XAxis dataKey="month" stroke="#64748B" fontSize={12} />
              <YAxis stroke="#64748B" fontSize={12} />
              <Tooltip
                contentStyle={{ background: '#151E32', border: '1px solid rgba(148, 163, 184, 0.2)', borderRadius: 8 }}
                labelStyle={{ color: '#F1F5F9' }}
              />
              <Legend />
              <Line type="monotone" dataKey="revenue" stroke="#3B82F6" strokeWidth={2} dot={{ r: 3 }} />
              <Line type="monotone" dataKey="profit" stroke="#10B981" strokeWidth={2} dot={{ r: 3 }} />
            </ReLineChart>
          </ResponsiveContainer>
        );
      case 'bar':
        return (
          <ResponsiveContainer width="100%" height="100%">
            <ReBarChart data={mockBarData} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
              <XAxis dataKey="region" stroke="#64748B" fontSize={12} />
              <YAxis stroke="#64748B" fontSize={12} />
              <Tooltip
                contentStyle={{ background: '#151E32', border: '1px solid rgba(148, 163, 184, 0.2)', borderRadius: 8 }}
              />
              <Legend />
              <Bar dataKey="sales" fill="#3B82F6" radius={[4, 4, 0, 0]} />
              <Bar dataKey="target" fill="#1E293B" stroke="#64748B" strokeWidth={1} radius={[4, 4, 0, 0]} />
            </ReBarChart>
          </ResponsiveContainer>
        );
      case 'pie':
        return (
          <ResponsiveContainer width="100%" height="100%">
            <RePieChart>
              <Pie
                data={mockPieData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={4}
                dataKey="value"
              >
                {mockPieData.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={palette[index % palette.length]} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{ background: '#151E32', border: '1px solid rgba(148, 163, 184, 0.2)', borderRadius: 8 }}
              />
              <Legend />
            </RePieChart>
          </ResponsiveContainer>
        );
      case 'area':
        return (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={mockLineData} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
              <defs>
                <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#3B82F6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
              <XAxis dataKey="month" stroke="#64748B" fontSize={12} />
              <YAxis stroke="#64748B" fontSize={12} />
              <Tooltip
                contentStyle={{ background: '#151E32', border: '1px solid rgba(148, 163, 184, 0.2)', borderRadius: 8 }}
              />
              <Area type="monotone" dataKey="revenue" stroke="#3B82F6" fillOpacity={1} fill="url(#colorRevenue)" />
            </AreaChart>
          </ResponsiveContainer>
        );
      case 'table':
        return (
          <div className="p-4 overflow-auto">
            <table className="w-full text-xs">
              <thead>
                <tr style={{ background: '#1E293B' }}>
                  {['Region', 'Sales', 'Target', 'Variance', 'Status'].map(h => (
                    <th key={h} className="text-left px-3 py-2 font-medium" style={{ color: '#94A3B8', borderBottom: '1px solid rgba(148, 163, 184, 0.2)' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {mockBarData.map((row, i) => (
                  <tr key={i} style={{ borderBottom: '1px solid rgba(148, 163, 184, 0.05)' }}>
                    <td className="px-3 py-2" style={{ color: '#F1F5F9' }}>{row.region}</td>
                    <td className="px-3 py-2" style={{ color: '#F1F5F9' }}>${row.sales.toLocaleString()}</td>
                    <td className="px-3 py-2" style={{ color: '#94A3B8' }}>${row.target.toLocaleString()}</td>
                    <td className="px-3 py-2" style={{ color: row.sales >= row.target ? '#10B981' : '#F43F5E' }}>
                      {((row.sales - row.target) / row.target * 100).toFixed(1)}%
                    </td>
                    <td className="px-3 py-2">
                      <Badge
                        variant="outline"
                        className="text-xs"
                        style={{
                          borderColor: row.sales >= row.target ? '#10B981' : '#F43F5E',
                          color: row.sales >= row.target ? '#10B981' : '#F43F5E',
                          background: row.sales >= row.target ? '#10B98115' : '#F43F5E15',
                        }}
                      >
                        {row.sales >= row.target ? 'On Track' : 'At Risk'}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="h-full flex flex-col">
      {/* Toolbar */}
      <div
        className="flex items-center justify-between px-4 py-2 border-b"
        style={{ background: '#151E32', borderColor: 'rgba(148, 163, 184, 0.1)' }}
      >
        <div className="flex items-center gap-2">
          <Input
            value="Q3 Revenue Overview"
            className="h-8 w-64 text-sm font-medium"
            style={{ background: '#1E293B', borderColor: 'rgba(148, 163, 184, 0.2)', color: '#F1F5F9' }}
          />
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" className="gap-1" style={{ color: '#94A3B8' }}>
            <Eye className="h-3.5 w-3.5" />
            <span className="text-xs">Preview</span>
          </Button>
          <Button variant="ghost" size="sm" className="gap-1" style={{ color: '#94A3B8' }}>
            <Save className="h-3.5 w-3.5" />
            <span className="text-xs">Save</span>
          </Button>
          <Button variant="ghost" size="sm" className="gap-1" style={{ color: '#94A3B8' }}>
            <Download className="h-3.5 w-3.5" />
            <span className="text-xs">Export</span>
          </Button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Widget Palette */}
        <div
          className="w-48 border-r p-3"
          style={{ background: '#151E32', borderColor: 'rgba(148, 163, 184, 0.1)' }}
        >
          <div className="text-xs font-medium mb-3" style={{ color: '#64748B' }}>WIDGETS</div>
          <div className="space-y-1">
            {widgetTypes.map(wt => (
              <button
                key={wt.type}
                onClick={() => addWidget(wt.type)}
                className="w-full flex items-center gap-2 px-3 py-2 rounded text-left transition-colors"
                style={{ color: '#94A3B8' }}
                onMouseEnter={e => { e.currentTarget.style.background = '#243447'; }}
                onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; }}
              >
                {wt.icon}
                <span className="text-xs">{wt.label}</span>
                <Plus className="h-3 w-3 ml-auto" style={{ color: '#64748B' }} />
              </button>
            ))}
          </div>
        </div>

        {/* Canvas */}
        <ScrollArea className="flex-1 p-6" style={{ background: '#0B1120' }}>
          <div
            className="min-h-full rounded-lg p-6"
            style={{
              background: '#0B1120',
              backgroundImage: 'radial-gradient(circle, rgba(148, 163, 184, 0.05) 1px, transparent 1px)',
              backgroundSize: '20px 20px',
            }}
          >
            <div className="grid grid-cols-4 gap-4 auto-rows-min">
              {widgets.map(widget => (
                <Card
                  key={widget.id}
                  className="border-0 overflow-hidden transition-all cursor-pointer"
                  style={{
                    background: '#151E32',
                    gridColumn: `span ${widget.w}`,
                    minHeight: widget.type === 'kpi' ? 120 : 280,
                    border: selectedWidget === widget.id ? '1px solid #3B82F6' : '1px solid rgba(148, 163, 184, 0.1)',
                  }}
                  onClick={() => {
                    setSelectedWidget(widget.id);
                    setEditTitle(widget.title);
                  }}
                >
                  {/* Widget Header */}
                  <div
                    className="flex items-center justify-between px-4 py-2 border-b"
                    style={{ borderColor: 'rgba(148, 163, 184, 0.05)' }}
                  >
                    <div className="flex items-center gap-2">
                      <GripVertical className="h-3 w-3" style={{ color: '#64748B' }} />
                      <span className="text-xs font-medium" style={{ color: '#F1F5F9' }}>{widget.title}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={(e) => { e.stopPropagation(); removeWidget(widget.id); }}
                        className="p-1 rounded"
                        onMouseEnter={e => { e.currentTarget.style.background = 'rgba(244, 63, 94, 0.1)'; }}
                        onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; }}
                      >
                        <Trash2 className="h-3 w-3" style={{ color: '#64748B' }} />
                      </button>
                    </div>
                  </div>

                  {/* Widget Content */}
                  <div className="flex-1" style={{ height: widget.type === 'kpi' ? 'auto' : 240 }}>
                    {renderWidget(widget)}
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}
