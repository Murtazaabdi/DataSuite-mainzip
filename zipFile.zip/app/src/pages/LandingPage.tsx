import { useNavigate } from 'react-router-dom';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import Lenis from 'lenis';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import FluidBackground from '@/components/FluidBackground';
import Navigation from '@/components/Navigation';
import HeroField from '@/sections/HeroField';
import PhilosophyCarousel from '@/sections/PhilosophyCarousel';
import ImmersiveGallery from '@/sections/ImmersiveGallery';
import MediumsGlossary from '@/sections/MediumsGlossary';
import Footer from '@/sections/Footer';
import ProjectDetail from '@/pages/ProjectDetail';
import { getProjectById } from '@/config';
import { ArrowRight, Sparkles, Shield, Database, Code2, BarChart3 } from 'lucide-react';
import { Button } from '@/components/ui/button';

gsap.registerPlugin(ScrollTrigger);

function LandingPage() {
  const navigate = useNavigate();
  const [fluidActive, setFluidActive] = useState(true);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const lenisRef = useRef<Lenis | null>(null);
  const savedScrollRef = useRef(0);
  const pendingScrollRef = useRef<number | null>(null);
  const selectedProject = selectedProjectId ? getProjectById(selectedProjectId) : null;

  const handleSelectProject = (id: string) => {
    savedScrollRef.current = window.scrollY;
    pendingScrollRef.current = 0;
    setSelectedProjectId(id);
  };

  const handleBack = () => {
    pendingScrollRef.current = savedScrollRef.current;
    setSelectedProjectId(null);
  };

  useLayoutEffect(() => {
    if (pendingScrollRef.current === null) return;
    const target = pendingScrollRef.current;
    pendingScrollRef.current = null;
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        lenisRef.current?.resize();
        lenisRef.current?.scrollTo(target, { immediate: true, force: true });
      });
    });
  }, [selectedProjectId]);

  useEffect(() => {
    const lenis = new Lenis({ lerp: 0.05 });
    lenisRef.current = lenis;
    lenis.on('scroll', ScrollTrigger.update);
    gsap.ticker.add((time) => { lenis.raf(time * 1000); });
    gsap.ticker.lagSmoothing(0);
    return () => { lenis.destroy(); };
  }, []);

  useEffect(() => {
    if (selectedProject) return;
    const heroEl = document.getElementById('hero-section');
    const philEl = document.getElementById('philosophy');
    const galleryEl = document.getElementById('gallery');
    if (!heroEl || !philEl || !galleryEl) return;

    const visibility = { hero: true, phil: false, gallery: false };
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.target === heroEl) visibility.hero = entry.isIntersecting;
          if (entry.target === philEl) visibility.phil = entry.isIntersecting;
          if (entry.target === galleryEl) visibility.gallery = entry.isIntersecting;
        });
        setFluidActive(visibility.hero || visibility.phil || visibility.gallery);
      },
      { threshold: 0.05 }
    );

    observer.observe(heroEl);
    observer.observe(philEl);
    observer.observe(galleryEl);
    return () => observer.disconnect();
  }, [selectedProject]);

  if (selectedProject) {
    return (
      <div style={{ position: 'relative' }}>
        <FluidBackground isActive={true} />
        <ProjectDetail project={selectedProject} onBack={handleBack} />
      </div>
    );
  }

  return (
    <div style={{ position: 'relative' }}>
      <FluidBackground isActive={fluidActive} />
      <Navigation />

      {/* Hero with CTA */}
      <div id="hero-section" style={{ position: 'relative', zIndex: 1 }}>
        <div className="relative">
          <HeroField />
          {/* Enterprise CTA Overlay */}
          <div
            className="absolute bottom-0 left-0 right-0 pb-16 pt-32 flex justify-center"
            style={{ background: 'linear-gradient(to top, #050A0F 0%, transparent 100%)' }}
          >
            <div className="flex gap-4">
              <Button
                size="lg"
                className="gap-2 text-sm"
                style={{ background: '#3B82F6', color: '#fff' }}
                onClick={() => navigate('/login')}
              >
                Get Started
                <ArrowRight className="h-4 w-4" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="gap-2 text-sm"
                style={{ borderColor: 'rgba(148, 163, 184, 0.3)', color: '#F1F5F9' }}
                onClick={() => navigate('/login')}
              >
                <Sparkles className="h-4 w-4" />
                Try AI Analyst
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div id="philosophy" style={{ position: 'relative', zIndex: 2 }}>
        <PhilosophyCarousel />
      </div>

      {/* Platform Features */}
      <div
        className="py-24 px-6"
        style={{ position: 'relative', zIndex: 3, background: '#050A0F' }}
      >
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-semibold mb-4" style={{ color: '#F1F5F9' }}>
              Enterprise-Grade Data Science Platform
            </h2>
            <p className="text-lg max-w-2xl mx-auto" style={{ color: '#94A3B8' }}>
              Everything you need to analyze, visualize, and operationalize your data — powered by AI.
            </p>
          </div>

          <div className="grid grid-cols-3 gap-8">
            {[
              {
                icon: <Code2 className="h-6 w-6" />,
                title: 'Multi-Language IDE',
                description: 'Write and execute Python, R, SQL, and JavaScript code with full syntax highlighting, autocomplete, and terminal output.',
                color: '#3B82F6',
              },
              {
                icon: <Database className="h-6 w-6" />,
                title: 'SQL Workbench',
                description: 'Query your data warehouse with a powerful SQL editor, schema browser, and results grid with export capabilities.',
                color: '#10B981',
              },
              {
                icon: <BarChart3 className="h-6 w-6" />,
                title: 'Dashboard Studio',
                description: 'Build beautiful, interactive dashboards with drag-and-drop widgets, real-time charts, and sharing options.',
                color: '#06B6D4',
              },
              {
                icon: <Sparkles className="h-6 w-6" />,
                title: 'AI Analyst',
                description: 'Chat with an AI data scientist that helps you write queries, analyze data, and build visualizations.',
                color: '#8B5CF6',
              },
              {
                icon: <Shield className="h-6 w-6" />,
                title: 'Enterprise Security',
                description: 'Role-based access control, 2FA for admins, audit logs, and encrypted API key storage.',
                color: '#F59E0B',
              },
              {
                icon: <Database className="h-6 w-6" />,
                title: 'Workspace & Docs',
                description: 'Create notebooks, documentation, and collaborative workspaces with embedded code and charts.',
                color: '#F43F5E',
              },
            ].map((feature, i) => (
              <div
                key={i}
                className="p-6 rounded-xl transition-all hover:-translate-y-1"
                style={{
                  background: '#151E32',
                  border: '1px solid rgba(148, 163, 184, 0.1)',
                }}
              >
                <div
                  className="w-12 h-12 rounded-lg flex items-center justify-center mb-4"
                  style={{ background: `${feature.color}15`, color: feature.color }}
                >
                  {feature.icon}
                </div>
                <h3 className="text-sm font-semibold mb-2" style={{ color: '#F1F5F9' }}>{feature.title}</h3>
                <p className="text-xs leading-relaxed" style={{ color: '#94A3B8' }}>{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Gallery */}
      <div id="gallery" style={{ position: 'relative', zIndex: 3 }}>
        <ImmersiveGallery onSelect={handleSelectProject} />
      </div>

      {/* Footer */}
      <div style={{ position: 'relative', zIndex: 50 }}>
        <div id="mediums">
          <MediumsGlossary />
        </div>
        <div id="footer">
          <Footer />
        </div>
      </div>
    </div>
  );
}

export default LandingPage;
