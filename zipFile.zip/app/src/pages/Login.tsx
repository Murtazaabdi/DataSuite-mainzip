import { useState } from 'react';

import { Shield, Database, ArrowRight, Smartphone, KeyRound } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

function getOAuthUrl() {
  const authUrl = new URL(`${import.meta.env.VITE_PORTAL_AUTH_URL}/oauth/authorize`);
  authUrl.searchParams.set("client_id", import.meta.env.VITE_APP_ID);
  authUrl.searchParams.set("redirect_uri", `${window.location.origin}/api/oauth/callback`);
  authUrl.searchParams.set("scope", "user.info");
  authUrl.searchParams.set("response_type", "code");
  const state = btoa(Math.random().toString()).slice(0, 22);
  authUrl.searchParams.set("state", state);
  sessionStorage.setItem("_oauth_state", state);
  return authUrl.toString();
}

export default function LoginPage() {
  const [loginStep, setLoginStep] = useState<'initial' | '2fa'>('initial');
  const [totpCode, setTotpCode] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async () => {
    setIsLoading(true);
    // Simulate login - in real app this would validate credentials
    setTimeout(() => {
      setIsLoading(false);
      // Check if admin - redirect to 2FA
      setLoginStep('2fa');
    }, 1000);
  };

  const handleVerify2FA = async () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      // In real app, this would verify the TOTP code
      window.location.href = getOAuthUrl();
    }, 1000);
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center p-4"
      style={{ background: '#0B1120' }}
    >
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div
              className="w-10 h-10 rounded-lg flex items-center justify-center"
              style={{ background: 'linear-gradient(135deg, #3B82F6, #06B6D4)' }}
            >
              <Database className="h-6 w-6 text-white" />
            </div>
            <span className="text-xl font-semibold" style={{ color: '#F1F5F9' }}>DS-PaaS</span>
          </div>
          <p className="text-sm" style={{ color: '#94A3B8' }}>
            Enterprise Data Science Platform
          </p>
        </div>

        <Card
          className="p-6 border-0"
          style={{ background: '#151E32', border: '1px solid rgba(148, 163, 184, 0.1)' }}
        >
          {loginStep === 'initial' && (
            <>
              <div className="text-center mb-6">
                <h1 className="text-lg font-semibold mb-1" style={{ color: '#F1F5F9' }}>
                  Sign in to your account
                </h1>
                <p className="text-xs" style={{ color: '#64748B' }}>
                  Access your data science workspace
                </p>
              </div>

              <div className="space-y-3 mb-6">
                <div>
                  <label className="text-xs block mb-1.5" style={{ color: '#94A3B8' }}>Email</label>
                  <Input
                    type="email"
                    placeholder="you@company.com"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="h-10 text-sm"
                    style={{ background: '#1E293B', borderColor: 'rgba(148, 163, 184, 0.2)', color: '#F1F5F9' }}
                  />
                </div>
                <div>
                  <label className="text-xs block mb-1.5" style={{ color: '#94A3B8' }}>Password</label>
                  <Input
                    type="password"
                    placeholder="Enter your password"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    className="h-10 text-sm"
                    style={{ background: '#1E293B', borderColor: 'rgba(148, 163, 184, 0.2)', color: '#F1F5F9' }}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" className="rounded" />
                    <span className="text-xs" style={{ color: '#94A3B8' }}>Remember me</span>
                  </label>
                  <button className="text-xs" style={{ color: '#3B82F6' }}>
                    Forgot password?
                  </button>
                </div>
              </div>

              <Button
                className="w-full h-10 text-sm mb-4"
                style={{ background: '#3B82F6', color: '#fff' }}
                onClick={handleLogin}
                disabled={isLoading}
              >
                {isLoading ? 'Signing in...' : 'Continue'}
                {!isLoading && <ArrowRight className="h-4 w-4 ml-2" />}
              </Button>

              <div
                className="flex items-center gap-3 my-4"
                style={{ color: '#64748B' }}
              >
                <div className="flex-1 h-px" style={{ background: 'rgba(148, 163, 184, 0.1)' }} />
                <span className="text-xs">or</span>
                <div className="flex-1 h-px" style={{ background: 'rgba(148, 163, 184, 0.1)' }} />
              </div>

              <Button
                variant="outline"
                className="w-full h-10 text-sm gap-2"
                style={{ borderColor: 'rgba(148, 163, 184, 0.2)', color: '#F1F5F9', background: '#1E293B' }}
                onClick={() => { window.location.href = getOAuthUrl(); }}
              >
                <Shield className="h-4 w-4" />
                Sign in with Kimi
              </Button>
            </>
          )}

          {loginStep === '2fa' && (
            <>
              <div className="text-center mb-6">
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3"
                  style={{ background: 'rgba(139, 92, 246, 0.15)' }}
                >
                  <Smartphone className="h-6 w-6" style={{ color: '#8B5CF6' }} />
                </div>
                <h1 className="text-lg font-semibold mb-1" style={{ color: '#F1F5F9' }}>
                  Two-Factor Authentication
                </h1>
                <p className="text-xs" style={{ color: '#64748B' }}>
                  Enter the 6-digit code from your authenticator app
                </p>
              </div>

              <div className="space-y-4 mb-6">
                <div className="flex justify-center gap-2">
                  {[0, 1, 2, 3, 4, 5].map(i => (
                    <Input
                      key={i}
                      maxLength={1}
                      className="w-12 h-12 text-center text-lg font-mono"
                      style={{ background: '#1E293B', borderColor: 'rgba(148, 163, 184, 0.2)', color: '#F1F5F9' }}
                      value={totpCode[i] || ''}
                      onChange={e => {
                        const val = e.target.value.replace(/\D/g, '');
                        const newCode = totpCode.split('');
                        newCode[i] = val;
                        setTotpCode(newCode.join('').slice(0, 6));
                        if (val && i < 5) {
                          const nextInput = e.target.parentElement?.querySelectorAll('input')[i + 1] as HTMLInputElement;
                          nextInput?.focus();
                        }
                      }}
                    />
                  ))}
                </div>
                <p className="text-xs text-center" style={{ color: '#64748B' }}>
                  Open your authenticator app (Google Authenticator, Authy, etc.) and enter the code.
                </p>
              </div>

              <Button
                className="w-full h-10 text-sm mb-3"
                style={{ background: '#8B5CF6', color: '#fff' }}
                onClick={handleVerify2FA}
                disabled={isLoading || totpCode.length !== 6}
              >
                {isLoading ? 'Verifying...' : 'Verify & Sign In'}
              </Button>

              <button
                onClick={() => setLoginStep('initial')}
                className="w-full text-center text-xs py-2"
                style={{ color: '#94A3B8' }}
              >
                Back to sign in
              </button>
            </>
          )}
        </Card>

        {/* Footer */}
        <div className="text-center mt-6">
          <div className="flex items-center justify-center gap-4 mb-3">
            <Badge variant="outline" className="text-xs gap-1" style={{ borderColor: 'rgba(148, 163, 184, 0.2)', color: '#64748B' }}>
              <Shield className="h-3 w-3" />
              SOC 2 Compliant
            </Badge>
            <Badge variant="outline" className="text-xs gap-1" style={{ borderColor: 'rgba(148, 163, 184, 0.2)', color: '#64748B' }}>
              <KeyRound className="h-3 w-3" />
              256-bit Encryption
            </Badge>
          </div>
          <p className="text-xs" style={{ color: '#475569' }}>
            Protected by enterprise-grade security. Admin access requires 2FA.
          </p>
        </div>
      </div>
    </div>
  );
}
