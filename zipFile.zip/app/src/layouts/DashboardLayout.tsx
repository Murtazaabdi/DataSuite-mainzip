import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import {
  FolderTree,
  Database,
  LayoutDashboard,
  Sparkles,
  FileText,
  Settings,
  Shield,
  Search,
  Bell,
  ChevronLeft,
  ChevronRight,
  X,
  LogOut,
  Code2,
  Terminal,
  BarChart3,
  Bot,
  BookOpen,
  Monitor,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';

interface Tab {
  id: string;
  label: string;
  path: string;
  icon: React.ReactNode;
}

const sidebarItems = [
  { id: 'explorer', label: 'Explorer', icon: <FolderTree className="h-5 w-5" />, path: '/dashboard/ide' },
  { id: 'sql', label: 'SQL Workbench', icon: <Database className="h-5 w-5" />, path: '/dashboard/sql' },
  { id: 'studio', label: 'Dashboard Studio', icon: <LayoutDashboard className="h-5 w-5" />, path: '/dashboard/studio' },
  { id: 'ai', label: 'AI Analyst', icon: <Sparkles className="h-5 w-5" />, path: '/dashboard/ai' },
  { id: 'workspace', label: 'Workspace', icon: <FileText className="h-5 w-5" />, path: '/dashboard/workspace' },
];

const bottomItems = [
  { id: 'settings', label: 'Settings', icon: <Settings className="h-5 w-5" />, path: '/dashboard/settings' },
];

export default function DashboardLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [tabs, setTabs] = useState<Tab[]>([]);
  const [activeTab, setActiveTab] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Sync tabs with route
  useEffect(() => {
    const path = location.pathname;
    const existingTab = tabs.find(t => t.path === path);
    if (!existingTab && path.startsWith('/dashboard')) {
      const tabLabels: Record<string, { label: string; icon: React.ReactNode }> = {
        '/dashboard': { label: 'Overview', icon: <Monitor className="h-4 w-4" /> },
        '/dashboard/ide': { label: 'IDE', icon: <Code2 className="h-4 w-4" /> },
        '/dashboard/sql': { label: 'SQL', icon: <Terminal className="h-4 w-4" /> },
        '/dashboard/studio': { label: 'Studio', icon: <BarChart3 className="h-4 w-4" /> },
        '/dashboard/ai': { label: 'AI Analyst', icon: <Bot className="h-4 w-4" /> },
        '/dashboard/workspace': { label: 'Workspace', icon: <BookOpen className="h-4 w-4" /> },
        '/dashboard/settings': { label: 'Settings', icon: <Settings className="h-4 w-4" /> },
      };
      const tabInfo = tabLabels[path] || { label: 'Tab', icon: <FileText className="h-4 w-4" /> };
      const newTab: Tab = {
        id: path,
        label: tabInfo.label,
        path,
        icon: tabInfo.icon,
      };
      setTabs(prev => [...prev, newTab]);
      setActiveTab(path);
    } else if (existingTab) {
      setActiveTab(path);
    }
  }, [location.pathname]);

  const closeTab = (e: React.MouseEvent, tabId: string) => {
    e.stopPropagation();
    setTabs(prev => {
      const newTabs = prev.filter(t => t.id !== tabId);
      if (activeTab === tabId && newTabs.length > 0) {
        const lastTab = newTabs[newTabs.length - 1];
        navigate(lastTab.path);
        setActiveTab(lastTab.path);
      } else if (newTabs.length === 0) {
        navigate('/dashboard');
      }
      return newTabs;
    });
  };

  const navigateTo = (path: string) => {
    navigate(path);
  };

  const isActive = (path: string) => location.pathname === path;

  const handleSearch = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && searchQuery.trim()) {
      setShowSearch(false);
      setSearchQuery('');
    }
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden" style={{ background: '#0B1120' }}>
      {/* ─── HEADER ─── */}
      <header
        className="flex items-center justify-between px-4 border-b"
        style={{
          height: 48,
          background: '#151E32',
          borderColor: 'rgba(148, 163, 184, 0.1)',
        }}
      >
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #3B82F6, #06B6D4)' }}>
              <Database className="h-4 w-4 text-white" />
            </div>
            <span className="text-sm font-semibold" style={{ color: '#F1F5F9' }}>DS-PaaS</span>
            {user?.role === 'admin' && (
              <Badge
                variant="outline"
                className="text-xs px-1.5 py-0 h-5 cursor-pointer"
                style={{ borderColor: '#8B5CF6', color: '#8B5CF6', background: 'rgba(139, 92, 246, 0.1)' }}
                onClick={() => navigate('/admin')}
              >
                ADMIN
              </Badge>
            )}
          </div>
          <div className="w-px h-5 mx-2" style={{ background: 'rgba(148, 163, 184, 0.2)' }} />
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              onClick={() => navigate(-1)}
            >
              <ChevronLeft className="h-4 w-4" style={{ color: '#94A3B8' }} />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              onClick={() => navigate(1)}
            >
              <ChevronRight className="h-4 w-4" style={{ color: '#94A3B8' }} />
            </Button>
          </div>
        </div>

        {/* Search Bar */}
        <div className="flex-1 max-w-md mx-4">
          <div
            className="flex items-center gap-2 px-3 py-1.5 rounded-md cursor-text"
            style={{ background: '#1E293B', border: '1px solid rgba(148, 163, 184, 0.2)' }}
            onClick={() => setShowSearch(true)}
          >
            <Search className="h-3.5 w-3.5" style={{ color: '#64748B' }} />
            <span className="text-xs" style={{ color: '#64748B' }}>Search files, commands, data...</span>
            <kbd className="ml-auto text-xs px-1.5 py-0.5 rounded" style={{ background: '#243447', color: '#64748B' }}>Ctrl+K</kbd>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="h-8 w-8 relative">
            <Bell className="h-4 w-4" style={{ color: '#94A3B8' }} />
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full" style={{ background: '#F43F5E' }} />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 px-2 flex items-center gap-2">
                <div
                  className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium"
                  style={{ background: 'linear-gradient(135deg, #3B82F6, #8B5CF6)', color: '#fff' }}
                >
                  {user?.name?.charAt(0)?.toUpperCase() || 'U'}
                </div>
                <span className="text-xs" style={{ color: '#94A3B8' }}>{user?.name || 'User'}</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent
              align="end"
              className="w-56"
              style={{ background: '#151E32', border: '1px solid rgba(148, 163, 184, 0.2)' }}
            >
              <DropdownMenuLabel style={{ color: '#F1F5F9' }}>
                <div className="flex flex-col">
                  <span>{user?.name || 'User'}</span>
                  <span className="text-xs font-normal" style={{ color: '#64748B' }}>{user?.email || ''}</span>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator style={{ background: 'rgba(148, 163, 184, 0.1)' }} />
              <DropdownMenuItem onClick={() => navigate('/dashboard/settings')} style={{ color: '#94A3B8' }}>
                <Settings className="h-4 w-4 mr-2" /> Settings
              </DropdownMenuItem>
              {user?.role === 'admin' && (
                <DropdownMenuItem onClick={() => navigate('/admin')} style={{ color: '#8B5CF6' }}>
                  <Shield className="h-4 w-4 mr-2" /> Admin Panel
                </DropdownMenuItem>
              )}
              <DropdownMenuSeparator style={{ background: 'rgba(148, 163, 184, 0.1)' }} />
              <DropdownMenuItem onClick={logout} style={{ color: '#F43F5E' }}>
                <LogOut className="h-4 w-4 mr-2" /> Logout
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>

      {/* ─── TAB BAR ─── */}
      {tabs.length > 0 && (
        <div
          className="flex items-center border-b overflow-x-auto"
          style={{
            height: 35,
            background: '#0B1120',
            borderColor: 'rgba(148, 163, 184, 0.1)',
          }}
        >
          {tabs.map(tab => (
            <div
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.path);
                navigate(tab.path);
              }}
              className="flex items-center gap-2 px-3 py-1.5 cursor-pointer text-xs border-r transition-colors"
              style={{
                background: activeTab === tab.path ? '#1E293B' : 'transparent',
                borderBottom: activeTab === tab.path ? '2px solid #3B82F6' : '2px solid transparent',
                color: activeTab === tab.path ? '#F1F5F9' : '#64748B',
                borderRightColor: 'rgba(148, 163, 184, 0.1)',
              }}
            >
              {tab.icon}
              <span>{tab.label}</span>
              <button
                onClick={(e) => closeTab(e, tab.id)}
                className="ml-1 p-0.5 rounded hover:bg-white/10"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* ─── MAIN AREA ─── */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <aside
          className="flex flex-col border-r transition-all duration-200"
          style={{
            width: sidebarCollapsed ? 48 : 240,
            background: '#151E32',
            borderColor: 'rgba(148, 163, 184, 0.1)',
          }}
        >
          <ScrollArea className="flex-1">
            <div className="py-2">
              {sidebarItems.map(item => (
                <button
                  key={item.id}
                  onClick={() => navigateTo(item.path)}
                  className="w-full flex items-center gap-3 px-3 py-2 transition-colors text-left"
                  style={{
                    background: isActive(item.path) ? '#243447' : 'transparent',
                    borderLeft: isActive(item.path) ? '3px solid #3B82F6' : '3px solid transparent',
                    color: isActive(item.path) ? '#F1F5F9' : '#94A3B8',
                  }}
                  onMouseEnter={e => {
                    if (!isActive(item.path)) e.currentTarget.style.background = '#1E293B';
                  }}
                  onMouseLeave={e => {
                    if (!isActive(item.path)) e.currentTarget.style.background = 'transparent';
                  }}
                >
                  {item.icon}
                  {!sidebarCollapsed && <span className="text-sm">{item.label}</span>}
                </button>
              ))}
            </div>

            <div
              className="mx-3 my-2"
              style={{ height: 1, background: 'rgba(148, 163, 184, 0.1)' }}
            />

            <div className="py-2">
              {bottomItems.map(item => (
                <button
                  key={item.id}
                  onClick={() => navigateTo(item.path)}
                  className="w-full flex items-center gap-3 px-3 py-2 transition-colors text-left"
                  style={{
                    background: isActive(item.path) ? '#243447' : 'transparent',
                    borderLeft: isActive(item.path) ? '3px solid #3B82F6' : '3px solid transparent',
                    color: isActive(item.path) ? '#F1F5F9' : '#94A3B8',
                  }}
                  onMouseEnter={e => {
                    if (!isActive(item.path)) e.currentTarget.style.background = '#1E293B';
                  }}
                  onMouseLeave={e => {
                    if (!isActive(item.path)) e.currentTarget.style.background = 'transparent';
                  }}
                >
                  {item.icon}
                  {!sidebarCollapsed && <span className="text-sm">{item.label}</span>}
                </button>
              ))}

              {user?.role === 'admin' && (
                <button
                  onClick={() => navigateTo('/admin')}
                  className="w-full flex items-center gap-3 px-3 py-2 transition-colors text-left"
                  style={{
                    background: isActive('/admin') ? 'rgba(139, 92, 246, 0.15)' : 'transparent',
                    borderLeft: isActive('/admin') ? '3px solid #8B5CF6' : '3px solid transparent',
                    color: isActive('/admin') ? '#8B5CF6' : '#94A3B8',
                  }}
                  onMouseEnter={e => {
                    if (!isActive('/admin')) e.currentTarget.style.background = 'rgba(139, 92, 246, 0.1)';
                  }}
                  onMouseLeave={e => {
                    if (!isActive('/admin')) e.currentTarget.style.background = 'transparent';
                  }}
                >
                  <Shield className="h-5 w-5" />
                  {!sidebarCollapsed && <span className="text-sm">Admin Panel</span>}
                </button>
              )}
            </div>
          </ScrollArea>

          {/* Collapse toggle */}
          <button
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            className="w-full flex items-center justify-center py-2 border-t transition-colors"
            style={{
              borderColor: 'rgba(148, 163, 184, 0.1)',
              color: '#64748B',
            }}
          >
            {sidebarCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </button>
        </aside>

        {/* Content Area */}
        <main className="flex-1 overflow-hidden" style={{ background: '#0B1120' }}>
          <Outlet />
        </main>
      </div>

      {/* Search Dialog */}
      <Dialog open={showSearch} onOpenChange={setShowSearch}>
        <DialogContent
          className="sm:max-w-lg p-0 gap-0"
          style={{ background: '#151E32', border: '1px solid rgba(148, 163, 184, 0.2)' }}
        >
          <div className="p-4">
            <Input
              placeholder="Search files, commands, data..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              onKeyDown={handleSearch}
              autoFocus
              className="border-0 bg-transparent text-lg focus-visible:ring-0 focus-visible:ring-offset-0"
              style={{ color: '#F1F5F9' }}
            />
          </div>
          <div className="px-4 pb-4">
            <div className="text-xs mb-2" style={{ color: '#64748B' }}>Quick Actions</div>
            <div className="space-y-1">
              {[
                { label: 'Open IDE', shortcut: 'Ctrl+1', action: () => { navigate('/dashboard/ide'); setShowSearch(false); } },
                { label: 'Open SQL Workbench', shortcut: 'Ctrl+2', action: () => { navigate('/dashboard/sql'); setShowSearch(false); } },
                { label: 'Open AI Analyst', shortcut: 'Ctrl+3', action: () => { navigate('/dashboard/ai'); setShowSearch(false); } },
                { label: 'Open Settings', shortcut: 'Ctrl+,', action: () => { navigate('/dashboard/settings'); setShowSearch(false); } },
              ].map(item => (
                <button
                  key={item.label}
                  onClick={item.action}
                  className="w-full flex items-center justify-between px-3 py-2 rounded-md text-left transition-colors"
                  style={{ color: '#94A3B8' }}
                  onMouseEnter={e => { e.currentTarget.style.background = '#1E293B'; }}
                  onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; }}
                >
                  <span className="text-sm">{item.label}</span>
                  <kbd className="text-xs px-1.5 py-0.5 rounded" style={{ background: '#243447', color: '#64748B' }}>{item.shortcut}</kbd>
                </button>
              ))}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
